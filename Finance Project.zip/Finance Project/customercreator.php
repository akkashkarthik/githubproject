<?php
session_start();
include("connection.php");
if($_POST["cus_name"]){
$_cus_name=$_POST["cus_name"];
$_cus_gender=$_POST["cus_gender"];
$_cus_address=$_POST["cus_address"];
$_cus_area=$_POST["cus_area"];
$_cus_state=$_POST["cus_state"];
$_cus_city=$_POST["cus_city"];
$_cus_phonenumber=$_POST["cus_phonenumber"];
$_cus_whatsappnumber=$_POST["cus_whatsappnumber"];
$_cus_proof_type=$_POST["cus_proof_type"];
$_cus_proof=$_POST["cus_proof"];
$_cus_bussinessname=$_POST["cus_bussinessname"];
$_cus_bussinessaddress=$_POST["cus_bussinessaddress"];
$_cus_b_area=$_POST["cus_b_area"];
$_cus_bussinesscity=$_POST["cus_bussinesscity"];
$_cus_bussinessstate=$_POST["cus_bussinessstate"];    
$_cus_bussinesslicense=$_POST["cus_bussinesslicense"];
$_refferal_id=$_POST["refferal_id"];
$_cus_loan_amount=$_POST["cus_loan_amount"];
$_cus_loan_due=$_POST["cus_loan_due"];
$_cus_amount_paid=$_POST["cus_amount_paid"];
$_created_by=$_SESSION["logged_user_id"]; 
$_hand_amt=$_POST["hand_amt"];
$_due_period=$_POST["due_period"];
$_due_period_type=$_POST["due_period_type"];
$_payment_duration=$_POST["payment_duration"];
$_cus_pincode=$_POST["cus_pincode"];
$_cus_bussiness_pincode=$_POST["cus_bussiness_pincode"];
$_cus_display_id=$_POST["cus_display_id"];
$business_id=$_SESSION["business_id"];
$_line=$_POST["line"];

$sql = "CALL sp_customer_creator('$_cus_name', $_cus_gender, '$_cus_address', $_cus_area, $_cus_state, $_cus_city, '$_cus_phonenumber',
'$_cus_whatsappnumber', $_cus_proof_type, '$_cus_proof', '$_cus_bussinessname', '$_cus_bussinessaddress', $_cus_b_area, $_cus_bussinesscity, $_cus_bussinessstate,
'$_cus_bussinesslicense', '$_refferal_id', $_cus_loan_amount, $_cus_loan_due, $_cus_amount_paid, $_created_by, $_hand_amt, 
$_due_period,$_hand_amt, $_due_period_type, $_payment_duration, '$_cus_pincode', '$_cus_bussiness_pincode', '$_cus_display_id', $business_id, $_line)";
$result = $conn->query($sql);
            if(!$result) echo "<script>alert('Error!!')</script>";
}
 else
{
    echo "<script>alert('value not received')</script>";

}


?>
