<?php
session_start();
include("connection.php");

  $conn1= new mysqli($servername, $username, $password, $dbname);

  if ($conn1->connect_error) {
      die("Connection Failed: ". $conn1->connect_error);
  } 



if(isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])){
    $logged_user_id=$_SESSION["logged_user_id"];
    $active_log_id=$_SESSION["active_log_id"];
    $business_id=$_SESSION["business_id"];
   $access_id =$_SESSION["access_id"] ;
   //echo "<script>alert('$business_id');</script>";

    if ($active_log_id!=0) {
    
        $sql = "CALL sp_validate_log('$active_log_id')";
        
        $result = $conn1->query($sql);
        if ($result === false) {
           die("Error executing the SQL query: " . $conn1->error);
       }
      
        if($result->num_rows > 0){
            // Fetching results
            $rows = $result->fetch_all(MYSQLI_ASSOC);
           
             foreach ($rows as $row) {
             $log_status= $row['_log_status'];
             
             
              
         
             }
            
        }
       }
   
        if ($log_status==0){
           header("Location: login.php");
   
        }
        else{
           $_SESSION["logged_user_id"] =$logged_user_id;
           $_SESSION["active_log_id"] = $active_log_id;
          $_SESSION["access_id"] = $access_id ;
           $_SESSION["business_id"]=$business_id; 
        }
}
else{
    header("Location: login.php");
}




if ($_POST["loan_amt"]) {
    $_cus_id=$_POST["cus_id"];
    $_loan_amt=$_POST["loan_amt"];
    $_hand_amt=$_POST["hand_amt"];
    $_comm_per=$_POST["comm_per"];
    $_comm_amt=$_POST["comm_amt"];
    $_due_period=$_POST["due_period"];
    $_due_amt=$_POST["due_amt"];
    $_approved_by=$_POST["approved_by"];
    $_loan_status=$_POST["loan_status"];
    $_due_period_type=$_POST["due_period_type"];
    $_payment_duration=$_POST["payment_duration"];
    $business_id=$_SESSION["business_id"];
    

$sql= "CALL sp_loan_creater( $_cus_id, $_loan_amt, $_hand_amt, $_comm_per, $_comm_amt, '$_due_period', $_due_amt,  '$_approved_by', '$_loan_status', '$_due_period_type', $_payment_duration, $business_id)";
echo $sql;
$result= $conn->query($sql);

                if(!$result) echo "<script>alert('Error!!')</script>";
}
 ?>
    
