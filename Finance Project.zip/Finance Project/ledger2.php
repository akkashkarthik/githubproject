<?php
session_start();

include 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
$conn1 = new mysqli($servername, $username, $password, $dbname);

if(isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])){
    $logged_user_id=$_SESSION["logged_user_id"];
    $active_log_id=$_SESSION["active_log_id"];
    $business_id=$_SESSION["business_id"];
    $access_id =$_SESSION["access_id"] ;
    
    if ($active_log_id!=0) {
    
        $sql = "CALL sp_validate_log('$active_log_id')";
        
        $result = $conn->query($sql);
        if ($result === false) {
           die("Error executing the SQL query: " . $conn->error);
       }
      
        if($result->num_rows > 0){
            // Fetching results
            $rows = $result->fetch_all(MYSQLI_ASSOC);
           
             foreach ($rows as $row) {
             $log_status= $row['_log_status'];
              }
            
        }
       }
   
        if ($log_status==0){
           header("Location: login.php");
   
        }
        else{
           $_SESSION["logged_user_id"] =$logged_user_id;
           $_SESSION["active_log_id"] = $active_log_id;
           $_SESSION["access_id"] = $access_id ;
            $_SESSION["business_id"]=$business_id; 
   
            if (isset($_POST['submit'])){
               $_reason=$_POST['reason'];
               $_amt_in=$_POST['amt'];
               $ledger_type=$_POST['ledger_type'];
            
               
               $_created_by=$logged_user_id; 



              $sql="CALL sp_ledger($logged_user_id, $business_id,$_amt_in,'$_reason',$ledger_type)"; 

              echo $sql;   
              $conn2 = new mysqli($servername, $username, $password, $db_name);

              $result = $conn2->query($sql);
              if (!$result) {
                  echo "<script>alert('Error!!')</script>";
              } else {
                  echo "<script>alert('Data inserted successfully!')</script>";
                
              }   


        }
    }
}



?>

<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <header>Ledger</header>
    <style>
        header{
            font-size:100px;
            font-weight:bold;
            font-family:serif;
            color:white;
        }
        body {font-family: Arial;}

        .tab {
            width: 100%;
            height: 100%;
           
            background-color:  #240046;
           
           
        }

        .tab button {
            background-color: yellow;
            border: none;
            color: green;
            font-size: 50px;
            font-weight: bold;
            font-weight:bold;
        font-family:serif;
            
        }

        .tab button.active {
            background-color: #3c096c;
            color: white;
            
        }

        .tabcontent {
            display: none;
            padding: 20px;
            width: 100%;
            height: 100%;
            background-color:   #240046;
            color: white;
            padding-right:40px;
            
        }

        input[type="text"] {
            width: 70%;
           height: 8%;
            box-sizing: border-box;
            margin-bottom: 10px;
            border-radius: 16px;
           
            
            font-size: 50px;
            font-weight:bold;
        font-family:serif;
        }
        label{
            font-size: 70px;
            font-weight:bold;
        font-family:serif;
        }

        .Createbtn5 {
            width: 70%;
           height: 10%;
            background-color:  #682860;
            color: white;
          
            border-radius: 16px;
            font-size: 70px;
            font-weight: bold;
    }
    .Createbtn5:hover{
        background-color: #DE3163;
    }
        .container
        {

            width: 100%;
            height: 100%;
            margin-left: 100px;
            background-color:  #240046;
            margin-bottom:200%;
          
        }
       
.tablinks{
    width: 70%;
    height: 10%;
    border-radius: 16px;
    margin-top: 100px;
    margin-left: 30px;
    margin-right: 30px ;
    font-size: 70px;
    font-weight:bold;
        font-family:serif;
    color: white;
    background-color: #682860;
}
.tablinks:hover{
    background-color: #DE3163;
}
i{
	font-size: 70px;
	color:white;
}
    </style>

<body>
<div class="container">
<div class="container5">
      <button class="tablinks" onclick="openCity(event, 'Gender')" id="defaultOpen">Investment <i class="fa-solid fa-indian-rupee-sign"></i></button>
       <button class="tablinks" onclick="openCity(event, 'States')">Expence <i class="fa-solid fa-comments-dollar"></i></button>
      
       
</div>


<div id="Gender" class="tabcontent">

    <form action="ledger.php" method="POST">
    <input type="hidden" name="ledger_type" value="1" id="ledger_type">
    <div class="container6">
        <div class="form6">
    </div>
       <div class="fields6">
        <div class="input-fields6">
            <label>Investment</label><br>
            <br>
            <input type="text" name="reason" required>
        </div>
        <div class="input-fields6">
            <label>Amount</label><br>
            <br>
            <input type="text" name="amt" required>
        </div><br>
        <br>

        <button class="Createbtn5"  value="submit" name="submit" id="submit">Submit <i class="fa-solid fa-right-to-bracket"></i></button>
    
    </div>
</div>
</div>
    </form>
    

<div id="States" class="tabcontent">
       <form action="ledger.php"method="POST">
              <input type="hidden" name="ledger_type" value="0" id="ledger_type">
        <div class="container6">
        <div class="form6">
    </div>
       <div class="fields6">
        <div class="input-fields6">
            <label>Expense</label><br>
            <br>
            <input type="text" name="reason" required>
        </div>
        <div class="input-fields6">
            <label>Amount</label><br>
            <br>
            <input type="text" name="amt" required>
        </div><br>
<br>
        <button class="Createbtn5"  value="submit" name="submit" id="submit">Submit <i class="fa-solid fa-right-to-bracket"></i></button>
    </div>
     </div>
     </div>

    </form>
    
</div>


<script>
function openCity(evt, cityName) {
var i, tabcontent, tablinks;
tabcontent = document.getElementsByClassName("tabcontent");
for (i = 0; i < tabcontent.length; i++) {
tabcontent[i].style.display = "none";
}
tablinks = document.getElementsByClassName("tablinks");
for (i = 0; i < tablinks.length; i++) {
tablinks[i].className = tablinks[i].className.replace(" active", "");
}
document.getElementById(cityName).style.display = "block";
evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();









</script>
</div>
</form>
</body>
</html>