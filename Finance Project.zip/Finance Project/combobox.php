<?php
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dynamic Select Box</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>

    <form>
       
        <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='pay_mode' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="Due-type">Due_Period</label>
                   <select  id="first_select">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
</select>
 <label for="second_select">Period_type:</label>
        <select id="second_select">
            <option value="">Select</option>
        </select>
    </form>

    <script>
        $(document).ready(function(){
            $('#first_select').change(function(){
                var firstSelectValue = $(this).val();

                $.ajax({
                    url: 'load_options.php',
                    type: 'POST',
                    data: {first_select_value: firstSelectValue},
                    success: function(data){
                        $('#second_select').html(data);
                    }
                });
            });
        });
    </script>

</body>
</html>