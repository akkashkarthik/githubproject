<?php
session_start();
include("connection.php");
?>
<html>
<style>
  
    table, td, th{
        background-color: #efcfe3;
        border: 1px solid black;
        font-size: 50px;
        font-weight: bold;
       
      font-family: serif;
      }
    #txtHint{
      width: 50%
        margin-top: 50px;
        overflow-x: scroll;
  overflow-y: hidden;
  white-space: nowrap;
  scroll-snap-type: x mandatory;
        
    }
    label{
      margin-top: 30px;
      font-size: 50px;
      font-weight: bold;
      font-family: serif;
      color: white;
    }
    select{
      margin-top: 30px;
      margin-left: 30px;
      width: 50%;
      height: 5%;
      font-size: 50px;
      font-weight: bold;
      font-family: serif;
    }   
    option{
      font-size: 15px;
      font-weight: bold;
      font-family: serif;
    }
    
</style>
<body>



<?php
    $query ="SELECT `pay_id`, `cus_id`, `loan_id`, `paid_amt`, `ledger_status`, `paid_at`, `received_by`, `bus_id` FROM `tbl_payments` WHERE ledger_status=1";
    $conn1= new mysqli($servername, $username, $password, $dbname);
    $result = $conn1->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    
    ?>
    <div id="txtHint">
<table>
<tr>
<th>Pay_Id</th>
<th>Customer-Id</th>
<th>Loan-Id</th>
<th>Paid-Amount</th>
<th>Ledger-Status</th>
<th>Paid-At</th>
<th>Received-By</th>
<th>Business-Id</th>
</tr>
<?php
               foreach ($row as $itemlist) {
               ?>
   <tr>
  <td><?php echo $itemlist['pay_id'] ?></td>
 <td><?php echo $itemlist['cus_id'] ?></td>
 <td> <?php echo $itemlist['loan_id'] ?> </td>
  <td><?php echo $itemlist['paid_amt'] ?></td>
  <td><?php echo $itemlist['ledger_status'] ?></td>
  <td><?php echo $itemlist['paid_at'] ?></td>
  <td><?php echo $itemlist['received_by'] ?></td>
 <td><?php echo $itemlist['bus_id'] ?></td>
  </tr>

  <?php } 
               ?>
</table>

    <?php 
    }
?> 

 

                  

</div>
</body>
</html>