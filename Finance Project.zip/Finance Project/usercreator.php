<?php
session_start();
include("connection.php");

if($_POST["user_gender"]){
    $_user_name=$_POST["user-name"];
    $_user_gender=$_POST["user_gender"];
    $_login_name=$_POST["login_name"];
    $_login_password=$_POST["login_password"];
    $_user_address=$_POST["user_address"];
    $_user_city=$_POST["user_city"];
    $_user_state=$_POST["user_state"];
    $_user_pincode=$_POST["user_pincode"];
    $_user_proof_type=$_POST["user_proof_type"];
    $_user_proof=$_POST["user_proof"];
    $_user_phonenumber=$_POST["user_phonenumber"];
    $_user_whatsappnumber=$_POST["user_whatsappnumber"];
    $_created_by=$_SESSION["logged_user_id"];
    $business_id=$_SESSION["business_id"];
    $access_id =$_SESSION["access_id"] ;

    $sql="CALL sp_user_creator('$_user_name', $_user_gender, '$_login_name', '$_login_password', '$_user_address', $_user_city, 
    $_user_state, '$_user_pincode', '$_user_proof', $_user_proof_type, '$_user_phonenumber', '$_user_whatsappnumber', '$_created_by', 
    $business_id,  $access_id)";
    $result=$conn->query($sql);
    if(!$result) echo "<script>alert('Error!!')</script>";
}
?>