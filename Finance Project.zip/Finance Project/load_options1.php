<?php
include("connection.php");
// Check if the POST data is set and not empty
if(isset($_POST['first_select_value']) && !empty($_POST['first_select_value'])){
    // Database connection or any other logic to get options for the second select box
    $firstSelectValue = $_POST['first_select_value'];
    
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='$firstSelecValue' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }

    $options = '';
  foreach ($row as $itemlist) {
    $add_id=$itemlist['addon_id'];
    $add_name=$itemlist['addon_name'];
    $options .= "<option value='$add_id'>$add_name</option>";
    

    
  
    }
    
}
   
  

    echo $options;

?>

