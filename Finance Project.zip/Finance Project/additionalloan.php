<?php
session_start();
include("connection.php");
?>
<html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
 body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: none;
        }

        .container {
            width: 80%;
            margin: 20px auto;
            background-color: rgba;
            padding: 20px;
            border-radius: 8px;
        
        }

        .fields{
            width:80%;
            padding-left: 80PX;
            margin-bottom: 20px;
    
        }

        header {
            
            font-size: 90px;
            font-weight: bold;
            font-family: serif;
            margin-bottom: 50px;
            color:white;
            padding-top: 60px;
        }

        .input-fields {
            margin-bottom: 50px;
        }

        label {
            display: block;
            margin-bottom: 30px;
            font-size: 50px;
            font-family: serif;
            font-weight: bold;
            color: white;
        }

        input,select
        {
            width:100%;
            padding: 28px;
            border: 1px solid #ccc;
            border-radius: 15px;
            box-sizing: border-box;
            font-size: 50px;
            font-family: serif;
            font-weight: bold;

        }
         
        .create-btn {
            background-color: #702963;
	width:100%;
	height:10%;
	 font-size: 75px;
	 font-family: serif;
	 font-weight: bold;
	 border: 1px solid #440f50;
	 border-radius: 15px;
	margin-top: 100px;
     color:white;
        }
       
        .create-btn:hover {
            background-color: #DE3163;
        }
        option{
            font-size:medium;
         }
        i{
            font-size: 70px;
        }
</style>		
<body>
<!--div class="container" >
    <div class="form first"-->
        <form action="loancreator.php" method="POST">
        <div class="fields">
      
            <div>
                <header>Additional Loan</header>
            </div>
            <div class="input-fields">
                <label>Customer-Id</label>
                <input list="browsers" name="cus_id" id="browser">

<datalist id="browsers">
  <option value="">
  <option value="">
  <option value="">
  <option value="">
  <option value="">
</datalist>
            </div>
            <div class="input-fields">
                <label>Loan-Amount</label>
                <input type="number" name="loan_amt">
            </div>
            <div class="input-fields">
                <label>Given-Amount</label>
                <input type="number" name="hand_amt">
            </div>
            <div class="input-fields">
            <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='pay_mode' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="Due-type">Due_Period</label>
                   <select  id="first_select" name="due_period">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
        <label for="second_select1">Select Option 2:</label>
         <select id="second_select1">
        </select>
    </div>
        <div class="input-fields">
        <label for="second_select">Period_type:</label>
        <select id="second_select" name="due_period_type">
            <option value="">Select</option>
        </select>
    </div>
            </div>
            <div class="input-fields">
                <label>Duration</label>
                <input type="number" name="payment_duration">
            </div>
            <div class="input-fields">
                <label>Install-Amount</label>
                <input type="number" name="payment_duration">
            </div>
            <div class="input-fields">
                <button type="submit" class="create-btn">Register <i class="fa-sharp fa-solid fa-cash-register"></i></button> 
            </div>
        </div>
        </form>
    <!--/div>
</div-->
<script>
        $(document).ready(function(){
            $('#first_select').change(function(){
                var firstSelectValue = $(this).val();

                $.ajax({
                    url: 'load_options.php',
                    type: 'POST',
                    data: {first_select_value: firstSelectValue},
                    success: function(data){
                        $('#second_select').html(data);
                    }
                });
            });
        });
    </script>
</body>
</html>