<?php
session_start();
include ("connection.php");
?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
h1{
    font-size:70px;
}
main.table {
    width: 90vw;
    height: 90vh;
    background-color: #fff5;

    backdrop-filter: blur(7px);
    box-shadow: 0 .4rem .8rem #0005;
    border-radius: .8rem;
    margin-left:20px;


    overflow: hidden;
}

.table__header {
    width: 100%;
    height: 10%;
    background-color: #fff4;
    padding: .8rem 1rem;
    margin-top:10%;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.table__header .input-group {
    width: 35%;
    height: 100%;
    background-color: #fff5;
    padding: 0 .8rem;
    border-radius: 2rem;

    display: flex;
    justify-content: center;
    align-items: center;

    transition: .2s;
}

.table__header .input-group:hover {
    width: 45%;
    background-color: #fff8;
    box-shadow: 0 .1rem .4rem #0002;
}

.table__header .input-group img {
    width: 1.2rem;
    height: 1.2rem;
}

.table__header .input-group input {
    width: 100%;
    padding: 0 .5rem 0 .3rem;
    background-color: transparent;
    border: none;
    outline: none;
}

.table__body {
    width: 95%;
    height:400px;
    min-height: calc(89% - 1.6rem);
    background-color: #fffb;

    margin: .8rem auto;
    border-radius: .6rem;

    overflow: auto;
    overflow: overlay;
}


.table__body::-webkit-scrollbar{
    width: 0.5rem;
    height: 0.5rem;
}

.table__body::-webkit-scrollbar-thumb{
    border-radius: .5rem;
    background-color: #0004;
    visibility: hidden;
}

.table__body:hover::-webkit-scrollbar-thumb{ 
    visibility: visible;
}


table {
    width: 100%;
}

td img {
    width: 36px;
    height: 36px;
    margin-right: .5rem;
    border-radius: 50%;

    vertical-align: middle;
}

table, th, td {
    border-collapse: collapse;
    padding: 1rem;
    text-align: left;
}

thead th {
    position: sticky;
    top: 0;
    left: 0;
    background-color: #d5d1defe;
    cursor: pointer;
    text-transform: capitalize;
}

tbody tr:nth-child(even) {
    background-color: #0000000b;
}

tbody tr {
    --delay: .1s;
    transition: .5s ease-in-out var(--delay), background-color 0s;
}

tbody tr.hide {
    opacity: 0;
    transform: translateX(100%);
}

tbody tr:hover {
    background-color: #fff6 !important;
}

tbody tr td,
tbody tr td p,
tbody tr td img {
    transition: .2s ease-in-out;
}

tbody tr.hide td,
tbody tr.hide td p {
    padding: 0;
    font: 0 / 0 sans-serif;
    transition: .2s ease-in-out .5s;
}

tbody tr.hide td img {
    width: 0;
    height: 0;
    transition: .2s ease-in-out .5s;
}

.status {
    padding: .4rem 0;
    border-radius: 2rem;
    text-align: center;
}

.status.delivered {
    background-color: #86e49d;
    color: #006b21;
}

.status.cancelled {
    background-color: #d893a3;
    color: #b30021;
}

.status.pending {
    background-color: #ebc474;
}

.status.shipped {
    background-color: #6fcaea;
}




thead th span.icon-arrow {
    display: inline-block;
    width: 1.3rem;
    height: 1.3rem;
    border-radius: 50%;
    border: 1.4px solid transparent;
    
    text-align: center;
    font-size: 1rem;
    
    margin-left: .5rem;
    transition: .2s ease-in-out;
}

thead th:hover span.icon-arrow{
    border: 1.4px solid #6c00bd;
}

thead th:hover {
    color: #6c00bd;
}

thead th.active span.icon-arrow{
    background-color: #6c00bd;
    color: #fff;
}

thead th.asc span.icon-arrow{
    transform: rotate(180deg);
}

thead th.active,tbody td.active {
    color: #6c00bd;
}





    </style>
<body>
    <main class="table" id="customers_table">
    <!-- <button id="btn">click me</button> -->
    <i class="fa-solid fa-xmark close"></i> <!-- Close icon -->

        <section class="table__header">
            <h1> Day close</h1>
        </section>
        <section class="table__body">
            <table>
                <thead>
                    <tr>   
                 <!-- <th>cus id</th>
                <th> Amount</th>
                <th> Date</th> -->
                
                                            
                    </tr>
                </thead>
                <tbody>
               <?php
if(isset($_GET['d_type']) && $_GET['d_type'] == 'staff') {
    $b_id = $_GET['b_id'];
    $user_id = $_GET['user_id'];
    $net_amt = 0; // Initialize net amount variable

    // Assuming you have a table named 'payments'
    $sql = "SELECT cus_id,paid_amt,paid_at FROM tbl_payments WHERE received_by=$user_id";
    $result = $conn5->query($sql);

    if ($result->num_rows > 0) {
        // Construct HTML table with payment details
        $output = '<table>';
        $output .= '<tr><th>User ID</th><th>Paid Amount</th><th>Date</th></tr>';
        while($row = $result->fetch_assoc()) {
            $net_amt += $row['paid_amt']; // Calculate net amount

            $output .= '<tr>';
            $output .= '<td>' . $row['cus_id'] . '</td>';
            $output .= '<td>' . $row['paid_amt'] . '</td>';
            $output .= '<td>' . $row['paid_at'] . '</td>';
            // $output .= '<td>' . $row['sum_amt'] . '</td>';
            $output .= '</tr>';
        }
        $output .= '</table>';

        // Send HTML content as response
        echo $output;
    } else {
        echo "No payments found for this user.";
    }
    echo '<tr><td colspan="3" style="text-align: right;">Total Sum Amount: ' . $net_amt . '</td></tr>';


    // Display total sum amount
    // echo '<tr><td colspan="3">Total Sum Amount: ' . $net_amt . '</td></tr>';

} else {
    echo "Invalid request";
}

           ?>
        
               <tr>
               <!-- <td colspan="5" style="text-align: right;"><?php echo $net_amt ;?> </td> -->
               </tr>
           
       
                </tbody>
               
            </table>
            <form method="POST" action="action3.php" class="form-close">
                            <input type="hidden" name="user_id" value="<?php echo  isset($itemlist['user_id']) ? $itemlist['user_id'] : ''; ?>"> 
                            <input type="hidden" name="net_amt" value="<?php echo  isset($itemlist['net_amt']) ? $itemlist['user_id'] : ''; ?>"> 

                            <!-- <button class="submit" id="approvel_id" name="submit" style="background-color:red;">approved</button> -->
                            
                             <button name="submit">Day close </button>
                        </form> 

           
        </section>
    </main>
   
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

$(document).ready(function(){
    $("#btn").click(function(){
       $("#customers_table").hide();
    });
});

$(document).ready(function(){
            $('.close').click(function(){
            console.log('close clicked');
             $(this).closest('main.table').hide();
                });
        });
</script>
    
</html>