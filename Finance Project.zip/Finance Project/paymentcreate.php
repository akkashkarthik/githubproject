<?php
session_start();
include 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);
$conn5 = new mysqli($servername, $username, $password, $dbname);


if(isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])){
  $logged_user_id=$_SESSION["logged_user_id"];
  $active_log_id=$_SESSION["active_log_id"];
  $business_id=$_SESSION["business_id"];
 $access_id =$_SESSION["access_id"] ;
  if ($active_log_id!=0) {
  
      $sql = "CALL sp_validate_log('$active_log_id')";
      
      $result = $conn->query($sql);
      if ($result === false) {
         die("Error executing the SQL query: " . $conn->error);
     }
    
      if($result->num_rows > 0){
          // Fetching results
          $rows = $result->fetch_all(MYSQLI_ASSOC);
         
           foreach ($rows as $row) {
           $log_status= $row['_log_status'];
           
           
            
       
           }
          
      }
     }
 
      if ($log_status==0){
         header("Location: login.php");
 
      }
      else{
         $_SESSION["logged_user_id"] =$logged_user_id;
         $_SESSION["active_log_id"] = $active_log_id;
        $_SESSION["access_id"] = $access_id ;
         $_SESSION["business_id"]=$business_id; 
      }
}
else{
  header("Location: login.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if(isset($_POST['phase'])) {
    $phase=$_POST['phase'];





    if ($phase==1) {


 $cus_id=$_POST['customer_id'];





 $query ="SELECT `loan_id`,`loan_amt` FROM `tbl_loans` WHERE `cus_id`='$cus_id' and loan_status=1 and bus_id=$business_id";
 $conn2 = new mysqli($servername, $username, $password, $dbname);

 $result = $conn2->query($query);

 if($result->num_rows > 0){
     // Fetching results
     $rows = $result->fetch_all(MYSQLI_ASSOC);
     
     // Generating options
     $options = '<option value=0>select loan</option>';
     foreach ($rows as $row) {
         $add_id = $row['loan_id'];
         $add_name = $row['loan_amt'];
         // Constructing options
         $options .= "<option value='$add_id'>$add_name</option>";
     }
    }








 

    $sql = "SELECT ( `cus_loan_amount`- `cus_amount_paid`)AS pen_amt FROM `tbl_customer` WHERE cus_userID=$cus_id and bus_id=$business_id";
 
    $conn3 = new mysqli($servername, $username, $password, $dbname);

     $result = $conn3->query($sql);
    if (!$result) {
        
    } else {
         
    if($result->num_rows> 0){
        $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
        foreach ($row as $itemlist) {
  
               $pen_amt=  $itemlist['pen_amt'];  
              }
            //   echo $pen_amt;

      }
  
      
    }
      $response = array('textData' => $pen_amt, 'textData2' =>  $phase, 'textData3' => $options);
        //      echo "<script>alert('$response')</script>";
         echo json_encode($response);
    }




    if ($phase==2) {


        $loan_id=$_POST['loan_id'];
       
       
       
       
       
        $query ="SELECT `pen_date`,`pen_id` FROM `tbl_pending` WHERE  `loan_id`=$loan_id AND`pen_status`=0 AND `pen_date`<=CURRENT_DATE and bus_id=$business_id";
        $conn4 = new mysqli($servername, $username, $password, $dbname);

        $result = $conn4->query($query);
         $options = "<option value=0>select date</option>";
        if($result->num_rows > 0){
            // Fetching results
            $rows = $result->fetch_all(MYSQLI_ASSOC);
            
            // Generating options
          
            foreach ($rows as $row) {
                $add_id = $row['pen_id'];
                $add_name = $row['pen_date'];
                // Constructing options
                $options .= "<option value='$add_id'>$add_name</option>";
            }
           }
       


           $sql = "CALL sp_loan_pending($loan_id )";
 

           $result = $conn5->query($sql);
          if (!$result) {
            $_balance='0';
            $pending_amt='0'; 
         
          
            $_due_amt='0';
              
          } else {
               
          if($result->num_rows> 0){
              $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
              foreach ($row as $itemlist) {
        
                     $_due_amt=  $itemlist['_due_amt'];  
                     $_balance=  $itemlist['_balance'];  
                     $pending_amt=  $itemlist['pending_amt'];  
                    }
                  //   echo $pen_amt;
      
            }
        
            
          }
       
       
       
       
       
     
        //   
             $response = array('textData' => $options, 'textData2' =>  $_due_amt, 'textData3' => $_balance, 'textData4' => $pending_amt);
               //      echo "<script>alert('$response')</script>";
                echo json_encode($response);
           }
           
           
          }


}
    

    ?>