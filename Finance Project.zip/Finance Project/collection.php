<?php
session_start();
include ("connection.php");
$conn1= new mysqli($servername, $username, $password, $dbname);
$conn= new mysqli($servername, $username, $password, $dbname);

if ($conn1->connect_error) {
    die("Connection Failed: ". $conn1->connect_error);
} 



if(isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])){
  $logged_user_id=$_SESSION["logged_user_id"];
  $active_log_id=$_SESSION["active_log_id"];
  $business_id=$_SESSION["business_id"];
 $access_id =$_SESSION["access_id"] ;
 //echo "<script>alert('$business_id');</script>";

  if ($active_log_id!=0) {
  
      $sql = "CALL sp_validate_log('$active_log_id')";
      
      $result = $conn1->query($sql);
      if ($result === false) {
         die("Error executing the SQL query: " . $conn1->error);
     }
    
      if($result->num_rows > 0){
          // Fetching results
          $rows = $result->fetch_all(MYSQLI_ASSOC);
         
           foreach ($rows as $row) {
           $log_status= $row['_log_status'];
           
           
            
       
           }
          
      }
     }
 
      if ($log_status==0){
         header("Location: login.php");
 
      }
      else{
         $_SESSION["logged_user_id"] =$logged_user_id;
         $_SESSION["active_log_id"] = $active_log_id;
        $_SESSION["access_id"] = $access_id ;
         $_SESSION["business_id"]=$business_id; 
      }
}
else{
  header("Location: login.php");
}
?>
<html>
<style>
  
    table, td, th{
      width: 100%;
        background-color: #9966CC;
        color: white;
        border: 1px solid black;
        font-size: 70px;
        font-weight: bold;
       font-family: serif;
      }
      th{
        background-color: #8D029B;
        color:white;
        padding:30px;
      }
    #txtHint{
      width: 50%
        margin-top: 50px;
        overflow-x: scroll;
  overflow-y: hidden;
  white-space: nowrap;
  scroll-snap-type: x mandatory;
        
    }
    label{
      margin-top: 30px;
      font-size: 50px;
      font-weight: bold;
      font-family: serif;
      color: white;
    }
    select{
      margin-top: 30px;
      margin-left: 30px;
      width: 50%;
      height: 5%;
      font-size: 50px;
      font-weight: bold;
      font-family: serif;
    }   
    option{
      font-size: 15px;
      font-weight: bold;
      font-family: serif;
    }
    h1{
      color:white;
      font-size: 100px;
      font-family: serif;
      font-weight: bold;
    }
</style>


<body>
<h1>Collection All</h1>


<?php
    $query ="CALL sp_collection_all($business_id);";
   
    $result = $conn->query($query);
  
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    
    ?>
<div id="txtHint">            
<table>
<tr>
<th>Loan Id</th>
<th>Loan Amount</th>
<th>Customer Name</th>
<th>Customer Whatsappnumber</th>
<th>Sum Amount</th>
</tr>   <?php
               foreach ($row as $itemlist) {
               ?>
 <tr> 
  <td><?php echo $itemlist['loan_id'] ?></td> 
  <td><?php echo $itemlist['loan_amt'] ?></td>
  <td><?php echo $itemlist['cus_name'] ?></td>
  <td><?php echo $itemlist['cus_whatsappnumber'] ?> </td>
  <td><?php echo $itemlist['sum_amt'] ?></td>
 </tr>
  <?php
}}?>
</table>

                   
</div>
</body>
</html>