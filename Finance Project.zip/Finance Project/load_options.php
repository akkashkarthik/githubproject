<?php
include("connection.php");

// Check if the POST data is set and not empty
if(isset($_POST['first_select_value']) && !empty($_POST['first_select_value'])){
    // Database connection or any other logic to get options for the second select box
    $firstSelectValue = $_POST['first_select_value'];
    
    // You should prepare the statement to prevent SQL injection
    $query ="SELECT `addon_id`, `addon_name` FROM `tbl_addons` WHERE `addon_type`='$firstSelectValue' AND `addon_status`=1";
    $result = $conn->query($query);
   
    if($result->num_rows > 0){
        // Fetching results
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        
        // Generating options
        $options = '';
        foreach ($rows as $row) {
            $add_id = $row['addon_id'];
            $add_name = $row['addon_name'];
            // Constructing options.
            $options .= "<option value='$add_id'>$add_name</option>";
        }
        echo $options;
    } else {
        echo "<option value=''>No options available</option>";
    }
} else {
    echo "<option value=''>Select</option>";
}
?>
