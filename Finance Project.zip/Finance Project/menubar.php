<?php
  session_start();
  include ("connection.php");

  $conn= new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
      die("Connection Failed: ". $conn->connect_error);
  } 



if(isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])){
    $logged_user_id=$_SESSION["logged_user_id"];
    $active_log_id=$_SESSION["active_log_id"];
    $business_id=$_SESSION["business_id"];
   $access_id =$_SESSION["access_id"] ;
   //echo "<script>alert('$business_id');</script>";

    if ($active_log_id!=0) {
    
        $sql = "CALL sp_validate_log('$active_log_id')";
        
        $result = $conn->query($sql);
        if ($result === false) {
           die("Error executing the SQL query: " . $conn->error);
       }
      
        if($result->num_rows > 0){
            // Fetching results
            $rows = $result->fetch_all(MYSQLI_ASSOC);
           
             foreach ($rows as $row) {
             $log_status= $row['_log_status'];
             
             
              
         
             }
            
        }
       }
   
        if ($log_status==0){
           header("Location: login.php");
   
        }
        else{
           $_SESSION["logged_user_id"] =$logged_user_id;
           $_SESSION["active_log_id"] = $active_log_id;
          $_SESSION["access_id"] = $access_id ;
           $_SESSION["business_id"]=$business_id; 
        }
}
else{
    header("Location: login.php");
}

 
?>  
<html>
<link rel="shortcut icon" type="x-icon" href="logo.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
 <style>
    body {
    margin: 0 0 55px 0;
    background-color:240046;
}

.nav {
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 10%;
    box-shadow: 0 0 3px rgba(0, 0, 0, 0.2);
    background-color:3c096c;
    color:white;
    display:flex;
    
    
}

.nav__link {
   
    padding-left: 100px;
    padding-right: 100px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex-grow: 1;
    min-width: 50px;
    overflow: hidden;
    white-space: nowrap;
    font-family: sans-serif;
    font-size: 13px;
    color:e0aaff;
    text-decoration: none;
    -webkit-tap-highlight-color: transparent;
    transition: background-color 0.1s ease-in-out;
    
}

.nav__link:hover {
    background-color:5a189a;
}

.nav__link{
    color:fffcf2;
}

i {
    font-size: 70px;
}
.nav__text{
  font-size: 35px;
  font-family: serif;
  font-weight: bold;
}

#popup {
  width:90%;
  height:80%;
        display:none;
        position: absolute;
        top: 45%;
        left: 30%;
        transform: translate(-50%, -50%) scale(1);
        background-color: #240046;
        padding: 5px;
        border-radius: 30px;
        /* border: 2px solid #000; */
        z-index: 1;
        visibility: visible;
        padding-bottom: 130px;
        margin-left:200px;
        padding-right:0px;
        margin-right:600px;
        overflow-x: hidden;
        overflow-y: scroll;
        scroll-snap-type: y mandatory;
        scroll-snap-align: start none;
        scroll-margin-block-start: 50px;
}
  
    .open-popup{
    visibility: visible;
    top: 50%;
    transform: translate(-50%, -50%) scale(1);
}
 .btn {
    display: grid;
    grid-template-columns: repeat(3, 2fr);
  background-color: #blue;   
  border:none;
  height: 100%;
  
}
/*.btn1 {
    display: flex;
  background-color: #f1f1f1;  
  border:none; 
  height: 30%;
}
.btn2{
    display: flex;
  background-color: #f1f1f1;
  height: 30%;
  border:none;
}
.btn3{
    display: flex;
    height: 30%;
    border:none;
} */
.cls{
   width: 100%;
   height: 80%;
   border: none;
   border-bottom: none;
   background-color: #240046; 
   color: white;
   font-size: 43px;
   font-weight: bold;
   
}
.bsect{
    width: 100%;
   height: 25%;
    border: none;
    
    
}


 /* .btn4{ 
    display: flex;
  background-color: #f1f1f1; 
  height: 20%;
  border:none;
} */
i{
    font-size: 100px;
    color:white;
}
.cls:hover{
    background-color: #9d4edd;
    color:black;
}
i:hover{
    color:black;
}
.nav__text:hover{
    color:black;
}
.nav__link:hover{
    color:black;
}
.clss{
    width: 300%;
   height: 100%;
   border: none;
   background-color: #240046; 
   color: white;
   font-size: 43px;
   font-weight: bold;
}
.clss:hover{
    background-color: #9d4edd;
    color:black;
}
img{
    width:70%;
    height:50%;
    margin-top:300px;
    margin-left: 50px;
    background-color: white;
    clip-path: circle();
    padding:50px 100px;
}
</style>
  <body> 
<img src="logo.png">

  

 <nav class="nav">
 
  <a href="#" class="nav__link" id="payment">
  <i class="fa-solid fa-circle-dollar-to-slot"></i>
    <span class="nav__text" >PAYMENT</span>
  </a>
  <a href="#" class="nav__link" id="menus">
  <i class="fa-solid fa-square-caret-up"></i>
    <span class="nav__text" >MENU</span>
  </a>
  <a href="#" class="nav__link" onclick="logout()">
  <i class="fa-sharp fa-solid fa-power-off"></i>
    <span class="nav__text">LOGOUT</span>
  </a>
</nav>

<div class="popup" id="popup">

</div>

  <script>
    $(document).ready(function(){
       $('#payment').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'loanpayments.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });

    $(document).ready(function(){
       $('#loan').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'loan.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#user').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'user.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#customer').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'customer.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#setting').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'setting.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#collection').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'collection.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#line').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'line.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#loanview').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'loanview.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
</script>
<script>
function logout(){
  window.location.href ="login.php";
}
$(document).ready(function(){
       $('#payview').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'paymentview.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#userview').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'userview.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#customerview').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'customerview.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#addloan').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'additionalloan.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#loanapprove').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'loanapprove.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#ledger').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'ledger2.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#allotment').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'allotment.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#dayclose').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'dayclose.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#menus').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'menus.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
</script>
<script>
    let popup=document.getElementById("popup");
           function openPopup(){
            popup.classList.add("open-popup");
           }
</script>
<script>
function logout(){
  window.location.href ="login.php";
}
</script>
</body>
</html>