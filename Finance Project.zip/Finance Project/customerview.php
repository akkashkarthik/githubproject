<?php
session_start();
include("connection.php");
?>
<html>
<style>
  
    table, td, th{
        background-color: #9966CC;
        border: 1px solid black;
        font-size: 70px;
        font-weight: bold;
       color:white;
      font-family: serif;
      }
      th{
        background-color: #8D029B;
        color:white;
        padding:30px;
      }
    #txtHint{
      width: 50%
        margin-top: 50px;
        overflow-x: scroll;
  overflow-y: hidden;
  white-space: nowrap;
  scroll-snap-type: x mandatory;
        
    }
    label{
      margin-top: 30px;
      font-size: 50px;
      font-weight: bold;
      font-family: serif;
      color: white;
    }
    select{
      margin-top: 30px;
      margin-left: 30px;
      width: 50%;
      height: 5%;
      font-size: 50px;
      font-weight: bold;
      font-family: serif;
    }   
    option{
      font-size: 15px;
      font-weight: bold;
      font-family: serif;
    }
    h1{
      font-size: 100px;
      font-family: serif;
      font-weight: bold;
      color: white;
    }
</style>


<body>
<h1>Customer View</h1>


<?php
    $query ="SELECT `cus_userID`, `cus_name`, `cus_gender`, `cus_address`, `cus_area`, `cus_state`, `cus_city`, `cus_phonenumber`, `cus_whatsappnumber`, `cus_proof_type`, `cus_proof`, `cus_bussinessname`, `cus_bussinessaddress`, `cus_b_area`, `cus_bussinesscity`, `cus_bussinessstate`, `cus_bussinesslicense`, `refferal_id`, `cus_loan_amount`, `cus_loan_due`, `cus_amount_paid`, `created_by`, `created_at`, `cus_status`, `cus_pincode`, `cus_bussiness_pincode`, `cus_display_id`, `cus_payment_duration`, `bus_id` FROM `tbl_customer` WHERE cus_status=1;";
    $conn1 = new mysqli($servername, $username, $password, $dbname);

    $result = $conn1->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    
    ?>
    <div id="txtHint">
              
               <table>
               <tr>
                 <th>cus_userID</th>
                 <th>Name</th>
                 <th>Gender</th>
                 <th>Address</th>
                 <th>State</th>
                 <th>City</th>
                 <th>Phonenumber</th>
                 <th>Whatsappnumber</th>
                 <th>Proof_type</th>
                 <th>Proof</th>
                 <th>Bussiness_Name</th>
                 <th>Bussiness_Address</th>
                 <th>Bussiness_City</th>
                 <th>Bussiness_State</th>
                 <th>Bussiness_license</th>
                 <th>Refferal_id</th>
                 <th>Loan_Amount</th>
                 <th>Loan_Due</th>
                 <th>Amount_paid</th>
                 <th>Created_by</th>
                 <th>Created_at</th>
                 <th>Cus_Status</th>
                 <th>Pincode</th>
                 <th>Business_Pincode</th>
                 <th>Display_Id</th>
                 <th>Payment_Duration</th>
               </tr>
              
             
             <?php
               foreach ($row as $itemlist) {
               ?>
               <tr>

    <td><?php echo  $itemlist['cus_userID'];?></td>
    <td><?php echo  $itemlist['cus_name'];?></td>
    <td><?php echo  $itemlist['cus_gender'];?></td>
    <td><?php echo  $itemlist['cus_address'];?></td>
    <td><?php echo  $itemlist['cus_state'];?></td>
    <td><?php echo  $itemlist['cus_city'];?></td>
    <td><?php echo  $itemlist['cus_phonenumber'];?></td>
    <td><?php echo  $itemlist['cus_whatsappnumber'];?></td>
    <td><?php echo  $itemlist['cus_proof_type'];?></td>
    <td><?php echo  $itemlist['cus_proof'];?></td>
    <td><?php echo  $itemlist['cus_bussinessname'];?></td>
    <td><?php echo  $itemlist['cus_bussinessaddress'];?></td>
    <td><?php echo  $itemlist['cus_bussinesscity'];?></td>
    <td><?php echo  $itemlist['cus_bussinessstate'];?></td>
    <td><?php echo  $itemlist['cus_bussinesslicense'];?></td>
    <td><?php echo  $itemlist['refferal_id'];?></td>
    <td><?php echo  $itemlist['cus_loan_amount'];?></td>
    <td><?php echo  $itemlist['cus_loan_due'];?></td>
    <td><?php echo  $itemlist['cus_amount_paid'];?></td>
    <td><?php echo  $itemlist['created_by'];?></td>
    <td><?php echo  $itemlist['created_at'];?></td>
    <td><?php echo  $itemlist['cus_status'];?></td>
    <td><?php echo  $itemlist['cus_pincode'];?></td>
    <td><?php echo  $itemlist['cus_bussiness_pincode'];?></td>
    <td><?php echo  $itemlist['cus_display_id'];?></td>
    <td><?php echo  $itemlist['cus_payment_duration'];?></td>
               </tr>
               <?php } 
               ?>
</table>

    <?php 
    }
?> 


</div>
</body>
</html>