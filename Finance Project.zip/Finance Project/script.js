$(document).ready(function() {
    $('.popup-btn').click(function() {
        var popupId = $(this).data('popup');
        var $popup = $('#' + popupId);

        // Make an AJAX request to fetch popup content
        $.ajax({
            url: 'popup_content.php', // Change this to your server-side script
            method: 'GET',
            data: { popupId: popupId },
            success: function(response) {
                $popup.html(response);
                $popup.show();
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
            }
        });
    });

    // Close popup when clicking outside of it
    $(document).click(function(event) {
        if (!$(event.target).closest('.popup-menu').length) {
            $('.popup').hide();
        }
    });
});
