<?php
session_start();
include("connection.php");
?>
<html>
<style>
  
    table, td, th{
        background-color: #9966CC;
        border: 1px solid black;
        font-size: 70px;
        font-weight: bold;
       color:white;
      font-family: serif;
      }
      th{
        background-color: #8D029B;
        color:white;
        padding:30px;
      }
    #txtHint{
      width: 50%
        margin-top: 50px;
        overflow-x: scroll;
  overflow-y: hidden;
  white-space: nowrap;
  scroll-snap-type: x mandatory;
        
    }
    label{
      margin-top: 30px;
      font-size: 50px;
      font-weight: bold;
      font-family: serif;
      color: white;
    }
    select{
      margin-top: 30px;
      margin-left: 30px;
      width: 50%;
      height: 5%;
      font-size: 50px;
      font-weight: bold;
      font-family: serif;
    }   
    option{
      font-size: 15px;
      font-weight: bold;
      font-family: serif;
    }
    h1{
      font-size: 100px;
      font-family: serif;
      font-weight: bold;
      color: white;
    }
    
</style>
<!-- <script>
function showUser(str) {
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","userviewcreator.php?q="+str,true);
    xmlhttp.send();
  }
}
</script> -->

<body>

<h1>User View</h1>

<?php
    $query ="SELECT `user_id`, `user_name`, `user_gender`, `login_name`, `login_password`, `user_address`, `user_city`, `user_state`, `user_pincode`, `user_proof_type`, `user_proof`, `user_phonenumber`, `user_whatsappnumber`, `created_by`, `created_at`, `log_id`, `user_status`, `bus_id`, `access_id` FROM `tbl_user` WHERE user_status=1;";
    $conn1 = new mysqli($servername, $username, $password, $dbname);
    $result = $conn1->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    
    ?>
    <div id="txtHint">
<table>
<tr>
<th>User_Id</th>
<th>User-Name</th>
<th>User-Gender</th>
<th>Login-Name</th>
<th>Login-Password</th>
<th>User-Address</th>
<th>User-City</th>
<th>User-State</th>
<th>User-Pincode</th>
<th>User-Prooftype</th>
<th>User-Proof</th>
<th>User-Phonenumber</th>
<th>User-Whatsappnumber</th>
<th>Created-By</th>
<th>Created-At</th>
<th>Log-Id</th>
<th>User-Status</th>
<th>Business-Id</th>
<th>Access-Id</th>
</tr>
<?php
               foreach ($row as $itemlist) {
               ?>
  <tr>
  <td><?php echo $itemlist['user_id']; ?></td>
 <td><?php echo $itemlist['user_name'];?></td>
 <td><?php echo $itemlist['user_gender']; ?></td>
  <td><?php echo $itemlist['login_name']; ?></td>
  <td><?php echo $itemlist['login_password']; ?></td>
  <td><?php echo $itemlist['user_address']; ?></td>
  <td><?php echo $itemlist['user_city']; ?></td>
  <td><?php echo $itemlist['user_state']; ?></td>
 <td><?php echo $itemlist['user_pincode']; ?></td>
 <td><?php echo $itemlist['user_proof_type']; ?></td>
  <td><?php echo $itemlist['user_proof']; ?></td>
 <td><?php echo $itemlist['user_phonenumber']; ?></td>
 <td><?php echo $itemlist['user_whatsappnumber']; ?></td>
  <td><?php echo $itemlist['created_by']; ?></td>
  <td><?php echo $itemlist['created_at']; ?></td>
  <td><?php echo $itemlist['log_id']; ?></td>
  <td><?php echo $itemlist['user_status']; ?></td>
  <td><?php echo $itemlist['bus_id']; ?></td>
  <td><?php echo $itemlist['access_id']; ?></td>
  </tr>
  <?php } 
               ?>
</table>

    <?php 
    }
?> 
             

</div>
</body>
</html>