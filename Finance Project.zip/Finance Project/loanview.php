<?php
session_start();
include("connection.php");
?>
<html>
<style>
    table, td, th{
        background-color: #9966CC;
        border: 1px solid black;
        font-size: 70px;
        font-weight: bold;
       color: white;
      font-family: serif;
      overflow-x: scroll;
  overflow-y: hidden;
  white-space: nowrap;
  scroll-snap-type: x mandatory;
      }
      th{
         background-color: #8D029B;
        color:white;
        padding:30px;
      }
    #txtHint{
      width: 100%
        margin-top: 50px;
        overflow-x: scroll;
  overflow-y: hidden;
  white-space: nowrap;
  scroll-snap-type: x mandatory;
        
    }
    label{
      margin-top: 30px;
      font-size: 50px;
      font-weight: bold;
      font-family: serif;
      color: white;
    }
    select{
      margin-top: 30px;
      margin-left: 30px;
      width: 50%;
      height: 5%;
      font-size: 50px;
      font-weight: bold;
      font-family: serif;
    }   
    option{
      font-size: 15px;
      font-weight: bold;
      font-family: serif;
    }
    h1{
      font-size: 100px;
      font-family: serif;
      font-weight: bold;
      color: white;
    }
</style>


<body>
<h1>Loan View</h1>


<?php
   $query ="SELECT `loan_id`, `cus_id`, `loan_amt`, `hand_amt`, `comm_per`, `comm_amt`, `due_period`, `due_amt`, `raised_at`, `approved_by`, 
   `loan_status`, `due_period_type`, `payment_duration`, `loan_paid`, `bus_id` FROM `tbl_loans` WHERE loan_status=1";
   $conn1 = new mysqli($servername, $username, $password, $dbname);

   $result = $conn1->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    
    ?>
    <div id="txtHint">
<table>
<tr>
<th>Loan-Id</th>
<th>Customer-Id</th>
<th>Loan-Amount</th>
<th>Handling-Amount</th>
<th>Commission-Percentage</th>
<th>Commission-Amount</th>
<th>Due-Period</th>
<th>Due-Amount</th>
<th>Raised-By</th>
<th>Approved-By</th>
<th>Loan-Status</th>
<th>Due-Period-Type</th>
<th>Payment-Duration</th>
<th>Loan-Paid</th>
<th>bus_id</th>
</tr>
<?php
               foreach ($row as $itemlist) {
               ?>
  <tr>
  <td><?php echo $itemlist['loan_id'] ?></td>
  <td><?php echo $itemlist['cus_id'] ?></td>
  <td><?php echo $itemlist['loan_amt'] ?></td>
  <td><?php echo $itemlist['hand_amt'] ?></td>
  <td><?php echo $itemlist['comm_per'] ?></td>
  <td><?php echo $itemlist['comm_amt'] ?></td>
  <td><?php echo $itemlist['cus_id'] ?></td>
  <td><?php echo $itemlist['due_period'] ?></td>
 <td><?php echo $itemlist['due_amt'] ?></td>
  <td><?php echo $itemlist['raised_at'] ?></td>
  <td><?php echo $itemlist['approved_by'] ?></td>
 <td><?php echo $itemlist['loan_status'] ?></td>
  <td><?php echo $itemlist['due_period_type'] ?></td>
  <td><?php echo $itemlist['payment_duration'] ?></td>
 <td><?php echo $itemlist['loan_paid'] ?></td>
 <td><?php echo $itemlist['bus_id'] ?></td>
  </tr>
  
  <?php } 
               ?>

</table>
    <?php 
    }
?> 
                   
                   


</div>
</body>
</html>