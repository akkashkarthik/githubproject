<html>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: serif;
    }
    :root{
        --clr: #081033;
    }
    body{
        display: flex;
        justify-content: center;
        background:var(--clr);
        
    }
    .navigation{
        width: 980px;
        height: 500px;
        background: #fff;
        position: absolute;
        top: 80%;
        display: flex;
        justify-content: space-around;
        align-items: center;
        border-radius:10px;
       margin-top: 220px;
        padding-bottom:150px;
        font-size: 15px;
        padding-right:100px;
        padding-left:100px;
        padding-top: 30px;
        
}

.navigation ul{
  display: flex;
  width: 350px;
 
}
.navigation ul li{
    position: relative;
    list-style: none;
    width: 70px;
    height:70px;
    z-index: 1;
}
.icon{
    bottom:150px;
}
.navigation ul li a{
    position: relative;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-direction: column;
    width: 110%;
    text-align: center;
    font-weight: 500;
}
.navigation ul li a .icon{
    position: relative;
    display: block;
    line-height:55px;
    font-size:10em;
    text-align: center;
    transition: 0.5s;
    color: var(--clr);
}
.navigation ul li.active a .icon{
    transform: translateY(-23px);
}
.navigation ul li a .text{
    position:absolute ;
    color: var(--clr);
    font-weight:400;
    font-size: 0.75em;
   letter-spacing:0.05em;
   transition: 0.5s;
   opacity: 0;
   transform: translateY(5px);
}
.navigation ul li.active a .text{
    opacity: 1;
    transform: translateY(30px);
}
.indicator{
    position: absolute;
    top: -10%;
    width: 100px;
    height: 100px;
    background: #29fd53;
    border-radius: 50%;
    border: 6px solid var(--clr);
    transition:0.5s;
}
.indicator::before{
    content: '';
    position: absolute;
    top:50%;
    left: -22px;
    width: 20px;
    height:20px;
    background: transparent;
    border-top-right-radius: 20px;
    box-shadow: 0px -10px 0 0 var(--clr);
}
.indicator::after{
    content: '';
    position: absolute;
    top:50%;
    right: -22px;
    width: 20px;
    height:20px;
    background: none;
    border-top-left-radius: 0px;
    box-shadow: -1px -10px 0 0 var(--clr);
}
.navigation ul li:nth-child(1).active ~ .indicator{
    transform: translateX(calc(70px * 0));
}
.navigation ul li:nth-child(2).active ~ .indicator{
    transform: translateX(calc(70px * 1));
}
.navigation ul li:nth-child(3).active ~ .indicator{
    transform: translateX(calc(70px * 2));
}
.navigation ul li:nth-child(4).active ~ .indicator{
    transform: translateX(calc(70px * 3));
}
.navigation ul li:nth-child(5).active ~ .indicator{
    transform: translateX(calc(70px * 4));
}
.popup {
background: #fff;
border-radius: 6px;
position: absolute;
padding-top: 10px;
width:50%;
height:30%;
top: 70%;
left: 50%;
transform: translate(-50%, -50%) scale(0.1);
text-align: center;
padding: 0 30px 30px;
color:black;
visibility: hidden;
transition: transform 0.4s, top 0.4s;
font-size:40px;
}

.open-popup{
    visibility: visible;
    top: 50%;
    transform: translate(-50%, -50%) scale(1);
}
.fa-sharp.fa-solid.fa-xmark{
   float: right;
   margin-top:10px;
}
i{
    font-size: 40px;
}
@media screen and (max-width: 768px) {
            .navigation ul li {
                width: 30%; /* Adjust width for smaller screens */
            }
        }

        @media screen and (max-width: 480px) {
            .navigation ul li {
                width: 45%; /* Adjust width for even smaller screens */
            }
            .navigation{
        width: 980px;
        height: 90px;
        background: #fff;
        position: absolute;
        top: 90%;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius:10px;
        margin-bottom: 550px;
        font-size: 15px;
        padding-right:100px;
        padding-left:100px;
       
}
}     


    </style>
    <body>
        <div class="navigation">
         <ul>
                <li class="list active">
                <a href="#" onclick="openPopup()">
                <span class="icon">
                <i class="fa-solid fa-sack-dollar"></i>
                </span>
                <span class="text">PAYMENT</span>
                </a>
                </li>
          <li class="list">
          <a href="#">
        <span class="icon">
        <i class="fa-solid fa-coins"></i>
        </span>
        <span class="text">LOAN</span>
          </a>
          </li>
          <li class="list">
          <a href="#">
        <span class="icon">
        <i class="fa-sharp fa-solid fa-user"></i>
        </span>
        <span class="text">USER</span>
          </a>
          </li> 
          <li class="list">
          <a href="#">
        <span class="icon">
        <i class="fa-sharp fa-solid fa-users"></i>
        </span>
        <span class="text">CUSTOMER</span>
          </a>
          </li> 
          <li class="list">
          <a href="#">
        <span class="icon">
        <i class="fa-sharp fa-solid fa-power-off"></i>
        </span>
        <span class="text">LOGOUT</span>
          </a>
          </li>
          <div class="indicator"></div>
         </ul>
        </div>    
        <div class="popup" id="popup">
        <i class="fa-sharp fa-solid fa-xmark" onclick="closePopup()"></i>
        <label>NAME</label><br>
<br>
<input type="text" placeholder="NAME" ><br>
<br>
<label>LOAN</label><br>
<br>
<input type="text" placeholder="LOAN" ><br>
<br>
<label>AMOUNT-PAY</label><br>
<br>
<input type="number" placeholder="AMOUNT-PAY"><br>
<br>
<button type="submit">PAY</button><br>
<br>
         </div>
           <script>
            const list= document.querySelectorAll('.list');
            function activelink(){
                list.forEach((item)=>
                item.classList.remove('active'));
                this.classList.add('active');
            }
            list.forEach((item)=>
            item.addEventListener('click',activelink));
        </script>
         <script>
           let popup=document.getElementById("popup");
           function openPopup(){
            popup.classList.add("open-popup");
           }
           <script>
           function closePopup(){
            popup.classList.remove("open-popup");
           }
         </script>

</body>
   
</html>