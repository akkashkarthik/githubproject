<?php 

session_start();

include "connection.php";

    $query ="SELECT `ledger_Id`, `record_description`, `amount_in`, `amount_out`, `net_amt`, `active_ledger` FROM `tbl_ledger`";
    $conn1 = new mysqli($servername, $username, $password, $dbname);

    $result = $conn1->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
    ?>