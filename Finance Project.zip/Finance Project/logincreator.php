<?php
session_start();

  $servername = "localhost";
    $username = "root";
    $password = "";
    $db_name = "vidyabha_col_agent";  
    $conn = new mysqli($servername, $username, $password, $db_name);
  


if($conn->connect_error)
{
    die("connection failed:".$conn->connect_error);
}
else{
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (!empty($_POST["login_name"])) {
    $user_name=$_POST['login_name'];
     $user_pass=$_POST['login_password'];
     $sql = "CALL sp_validate_user('$user_name','$user_pass','123')";
     
     $result = $conn->query($sql);
     if ($result === false) {
        die("Error executing the SQL query: " . $conn->error);
    }
   
     if($result->num_rows > 0){
         // Fetching results
         $rows = $result->fetch_all(MYSQLI_ASSOC);
          foreach ($rows as $row) {
            $_SESSION["logged_user_id"] = $row['_user_id'];
            $_SESSION["active_log_id"] = $row['_log_id'];
            header("Location: menubar2.php");
      
          
         }
     }
         
       
    
   }
   
}
    }

?>
