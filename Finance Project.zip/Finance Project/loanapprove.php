<?php
 
session_start();
include("connection.php");
   $conn = new mysqli($servername, $username, $password, $dbname);
   $conn1 = new mysqli($servername, $username, $password, $dbname);
   $conn2 = new mysqli($servername, $username, $password, $dbname);
   if(isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])){
    $logged_user_id=$_SESSION["logged_user_id"];
    $active_log_id=$_SESSION["active_log_id"];
    $business_id=$_SESSION["business_id"];
    
    $access_id =$_SESSION["access_id"] ;
    
    if ($active_log_id!=0) {
    
        $sql = "CALL sp_validate_log('$active_log_id')";
        
        $result = $conn->query($sql);
        if ($result === false) {
           die("Error executing the SQL query: " . $conn->error);
       }
      
        if($result->num_rows > 0){
            // Fetching results
            $rows = $result->fetch_all(MYSQLI_ASSOC);
           
             foreach ($rows as $row) {
             $log_status= $row['_log_status'];
            }
            
        }
       }
       if ($log_status==0){
        header("Location: login.php");

     }
     else{
        $_SESSION["logged_user_id"] =$logged_user_id;
        $_SESSION["active_log_id"] = $active_log_id;
        $_SESSION["access_id"] = $access_id ;
        $_SESSION["business_id"]=$business_id;  

        if (isset($_POST['submit'])){
            $_loan_id=$_POST['loan_id'];
            
            $sql="CALL sp_approvel_loan($_loan_id,$logged_user_id,$business_id)";
            echo $sql;
            $result = $conn2->query($sql);
            if (!$result) {
                echo "<script>alert('Error!!')</script>";
            } else {
                header("Location: menubar.php");
            }
        }

    
}
   }
        ?>




        <html>
       
            <style>
                table {
                    width: 100%;
                    height: 80%;
                    font-size:70px;
                    font-family: serif;
                    font-weight: bold;
                    color: white;
                    gap:5px;
                    margin-top:150px;
                    border: 1px solid black;
                    background-color: #9966CC;
                    overflow-x: scroll;
                    overflow-y: hidden;
                    white-space: nowrap;
                    scroll-snap-type: x mandatory;
                    scroll-snap-type: y mandatory;
                }

                th, td {
                    padding: 30px;
                    text-align: left;
                    border: 1px solid black;
                    font-size:70px;
                    overflow-x: scroll;
                    overflow-y: hidden;
                    white-space: nowrap;
                    scroll-snap-type: x mandatory;
                    scroll-snap-type: y mandatory;
                }

                th {
                    border-bottom: 1px solid black;
                    background-color:#8D029B;
                    color: white;
                }
                     
                .details {
                    display: flex;
                    overflow-x: scroll;
                    overflow-y: hidden;
                    white-space: nowrap;
                    scroll-snap-type: x mandatory;
                   }
                #submit {
                    margin-top: 40px;
                    width: 100%;
                    height: 15%;
                    font-size: 60px;
                    color: white;
                    background-color: #8B004B;
                   
                }
                #submit:hover{
                    background-color: #DE3163;
                }
              h1{
                font-size: 100px;
                font-family: serif;
                font-weight: bold;
                color: white;
              }
            </style>
        
        <body>
    
<h1>Loan Approve</h1>
<div class="details">
            <?php
                $query ="SELECT `loan_id`, `cus_id`, `loan_amt`, `hand_amt`, `comm_per`, `comm_amt`, `due_period`, `due_amt`, `raised_at`, `approved_by`, 
                `loan_status`, `due_period_type`, `payment_duration`, `loan_paid`, `bus_id` FROM `tbl_loans` WHERE loan_status=1";
                $result = $conn1->query($query);
                if($result->num_rows > 0){
                    $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
             ?>
                   
                    <table >
                        <tr>
                            <th>Customer Id</th>
                            <th>Loan Amount</th>
                            <th>Handling Amount</th>
                            <th>Due Period</th>
                            <th>Period Type</th>
                            <th>Payment Duration</th>
                            <th>Due Amount</th>
                            <th>Action</th>
                        </tr>
            <?php
            foreach ($row as $itemlist) {
                ?>
                <tr>
                    <td><?php echo  $itemlist['cus_id']; ?></td>
                    <td><?php echo  $itemlist['loan_amt']; ?></td>
                    <td><?php echo  $itemlist['hand_amt']; ?></td>
                    <td><?php echo  $itemlist['due_period']; ?></td>
                    <td><?php echo  $itemlist['due_period_type']; ?></td>
                    <td><?php echo  $itemlist['payment_duration']; ?></td>
                    <td><?php echo  $itemlist['due_amt']; ?></td>
                    <td>
                        <form method="POST"  class="form-close">
                            <input type="hidden" name="loan_id" value="<?php echo  $itemlist['loan_id'];?>"> 
                            <button class="submit" id="submit" name="approvel_id">Approved</button>
                        </form> 
                    </td>
                </tr>
                <?php
            }    }
            ?>
        </table>
        </div>
    <?php
    
?>
</body>
</html>