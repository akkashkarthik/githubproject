<?php
session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html>

    <style>
       

        .container {
            width: 80%;
            margin: 20px auto;
            background-color: rgba;
            padding: 20px;
            border-radius: 8px;
           
        }

        .form {
            width:100%;
            margin-bottom: 20px;
        }

        header {
            font-size: 60px;
            font-weight: bold;
            font-family: serif;
            margin-bottom: 10px;
            color:white;
        }

        .input-fields {
            margin-bottom: 50px;
        }

        label {
            display: block;
            margin-bottom: 30px;
            font-size: 50px;
            font-family: serif;
            font-weight: bold;
            color: white;
        }
         select{
            width:100%;
            padding: 28px;
            border: 1px solid black;
            border-radius:15px;
            box-sizing: border-box;
            font-size: 50px;
            font-family: serif;
            font-weight: bold;
         }
        input
        {
            width:100%;
            padding: 28px;
            border: 1px solid black;
            border-radius:15px;
            box-sizing: border-box;
            font-size: 50px;
            font-family: serif;
            font-weight: bold;

        }
         option{
            font-size:20px;
         }
        .create-btn {
            background-color: #702963;
	width:100%;
	height:10%;
	 font-size: 75px;
	 font-family: serif;
	 font-weight: bold;
	 border: 1px solid #440f50;
	 border-radius: 15px;
	
     color:white;
        }

        .create-btn:hover {
            background-color: #DE3163;
        }
       i{
        font-size: 70px;
       }
       option{
        font-size:20px;
       }
       header{
        font-size:85px;
            font-family:serif;
            font-weight:bold;
       }
   </style>
<body>
<div class="container">
    <div class="form first">
        <header>Customer Details</header><br>
        <br>
        <form action="customercreator.php" method="POST">
            <div class="fields">
                <div class="input-fields">
                    <label>Name</label>
                    <input type="text" name="cus_name">
                </div>
                <div class="input-fields">
                <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='gender' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="Gender">Gender</label>
                   <select  name="cus_gender" id="gender">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
                       
                   </select>
               </div>
                </div>
                <div class="input-fields">
                    <label>Address</label>
                    <input type="text" name="cus_address">
                </div>
                <div class="input-fields">
                <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='area' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="area">Area</label>
                   <select  name="cus_area" id="area">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
</select>
               

            </div>
                </div>
                <div class="input-fields">
                <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='City' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="City">City</label>
                   <select  name="cus_city" id="City">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
                       
                   </select>
               </div>
                </div>
                <div class="input-fields">
                <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='State' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="State">State</label>
                   <select  name="cus_state" id="State">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
                       
                   </select>
               </div>
                </div>
                <div class="input-fields">
                    <label>Phone-Number</label>
                    <input type="number" name="cus_phonenumber">
                </div>
                <div class="input-fields">
                    <label>Whatsapp_Number</label>
                    <input type="number" name="cus_whatsappnumber">
                </div>
                <div class="input-fields">
                <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='Proof' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="Proof-Type">Proof-Type</label>
                   <select  name="cus_proof_type" id="proof">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
                       
                   </select>
               </div>
                </div>
                <div class="input-fields">
                    <label>Proof-Number</label>
                    <input type="text" name="cus_proof">
                </div>
                <div class="input-fields">
                <label>Business-Name</label>
                <input type="text" name="cus_bussinessname">
            </div>
            <div class="input-fields">
                <label>Business-Address</label>
                <input type="text" name="cus_bussinessaddress">
            </div>
            <div class="input-fields">
            <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='area' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="area">Business-Area</label>
                   <select  name="cus_b_area" id="area">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
</select>
               

            </div>
            </div>
            <div class="input-fields">
            <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='City' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="City">Business-City</label>
                   <select  name="cus_bussinesscity" id="City">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
                       
                   </select>
               </div>
            </div>
            <div class="input-fields">
            <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='State' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="State">Business-State</label>
                   <select  name="cus_bussinessstate" id="State">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
                       
                   </select>
               </div>
            </div>
            <div class="input-fields">
                <label>Business-License</label>
                <input type="text" name="cus_bussinesslicense">
            </div>
            <div class="input-fields">
                <label>Referral-ID</label>
                <input list="bow" name="refferal_id" id="ref">
                <datalist id="bow">
                    <option value="1">
                    <option value="2">
                    <option value="3">
                </datalist>
            </div>
            <div class="input-fields">
                <label>Loan-Amount</label>
                <input type="number" name="cus_loan_amount">
            </div>
           <div class="input-fields">
                <label>Due</label>
                <input type="number" name="cus_loan_due">
            </div>
            <div class="input-fields">
                <label>Paid</label>
                <input type="number" name="cus_amount_paid">
            </div>
                <div class="input-fields">
                    <label>Pincode</label>
                    <input type="text" name="cus_pincode">
                </div>
                <div class="input-fields">
                <label>Business-Pincode</label>
                <input type="text" name="cus_bussiness_pincode">
            </div>
            <div class="input-fields">
            <?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='pay_mode' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="Due-type">Due-Period</label>
                   <select  id="first_select" name="due_period">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
        <label for="second_select1">Select Option 2:</label>
         <select id="second_select1">
        </select>
    </div>
        <div class="input-fields">
        <label for="second_select">Period-type</label>
        <select id="second_select" name="due_period_type">
            <option value="">Select</option>
        </select>
    </div>

            <div class="input-fields">
             <label>Handling-Amount</label>
             <input type="number" name="hand_amt">
            </div>

            
            <div class="input-fields">
               <label>Payment-Duration</label>
               <input type="number" name="payment_duration">
            </div>
            <div class="input-fields">
               <label>Display-id</label>
               <input type="text" name="cus_display_id">
            </div>
            <div class="input-fields">
            <label for="browser">Line</label>
<input list="browsers" name="line" id="browser">

<datalist id="browsers">
  <option value="1">
  <option value="2">
  <option value="3">
  <option value="4">
  <option value="5">
</datalist>
               
            </div>
            <div class="input-fields">
                <button type="submit"  class="create-btn">Create <i class="fa-sharp fa-solid fa-circle-plus"></i></button>
            </div>
            </div>
</div>
</div>
</form>
</div>
    <script>
        $(document).ready(function(){
            $('#first_select').change(function(){
                var firstSelectValue = $(this).val();

                $.ajax({
                    url: 'load_options.php',
                    type: 'POST',
                    data: {first_select_value: firstSelectValue},
                    success: function(data){
                        $('#second_select').html(data);
                    }
                });
            });
        });
    </script>
</body>
</html>