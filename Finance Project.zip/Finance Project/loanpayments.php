<?php
session_start();
$_SESSION["logged_user_id"]=1;
$_log_id = $_SESSION["logged_user_id"];
include 'connection.php';
$conn = new mysqli($servername, $username, $password, $dbname);

if(isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])){
    $logged_user_id=$_SESSION["logged_user_id"];
    $active_log_id=$_SESSION["active_log_id"];
    $business_id=$_SESSION["business_id"];
   $access_id =$_SESSION["access_id"] ;
    if ($active_log_id!=0) {
    
        $sql = "CALL sp_validate_log('$active_log_id')";
        
        $result = $conn->query($sql);
        if ($result === false) {
           die("Error executing the SQL query: " . $conn->error);
       }
      
        if($result->num_rows > 0){
            // Fetching results
            $rows = $result->fetch_all(MYSQLI_ASSOC);
           
             foreach ($rows as $row) {
             $log_status= $row['_log_status'];
             
             
              
         
             }
            
        }
       }
   
        if ($log_status==0){
           header("Location: login.php");
   
        }
        else{
           $_SESSION["logged_user_id"] =$logged_user_id;
           $_SESSION["active_log_id"] = $active_log_id;
          $_SESSION["access_id"] = $access_id ;
           $_SESSION["business_id"]=$business_id; 
        }
}
else{
    header("Location: login.php");
}

$conn1 = new mysqli($servername, $username, $password, $dbname);

if ($conn1->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $_pay = $_POST['pay'];
    $_cus_id = $_POST['cus_detail'];
    $_loan_id = $_POST['comboBox'];
    $_paid_amt = $_POST['balance'];
    $_received_by = $_log_id;
    $_pen_date = $_POST['date_id'];

    $sql = "CALL sp_pay($_cus_id, $_loan_id, $_paid_amt, $_received_by, $_pen_date,$business_id)";

    // Execute the SQL query here

    
  echo $sql;
  $conn5 = new mysqli($servername, $username, $password, $dbname);

    $result = $conn5->query($sql);
    if (!$result) {
        echo "<script>alert('Error!!')</script>";
    } else {
        echo "<script>alert('Data inserted successfully!')</script>";
      
    }
}


//  $cus_id=$_POST['first_select_value'];

//     $sql = "SELECT ( `cus_loan_amount`- `cus_amount_paid`)AS pen_amt FROM `tbl_customer` WHERE cus_userID=$cus_id";
 

//      $result = $conn->query($sql);
//     if (!$result) {
        
//     } else {
         
//     if($result->num_rows> 0){
//         $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
//         foreach ($row as $itemlist) {
  
//                $pen_amt=  $itemlist['pen_amt'];  
//               }
//              echo $pen_amt;
//              echo "<script>alert('$pen_amt')</script>";
//       }

      
//     }
    
//     }

    // if ($_SERVER["REQUEST_METHOD"] == "GET") {

    //     $cus_id=$_GET['cus_id'];
    //     echo "<script>alert('$cus_id')</script>";
    //        $sql = "SELECT ( `cus_loan_amount`- `cus_amount_paid`)AS pen_amt FROM `tbl_customer` WHERE cus_userID=$cus_id";
        
       
    //         $result = $conn->query($sql);
    //        if (!$result) {
               
    //        } else {
                
    //        if($result->num_rows> 0){
    //            $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    //            foreach ($row as $itemlist) {
         
    //                   $pen_amt=  $itemlist['pen_amt'];  
    //                  }
    //                 echo $pen_amt;
                   
    //          }
       
             
    //        }
           
    //        }


?> 



<!DOCTYPE html>
<html lang="en">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .payment {
            width: 90%;
            margin: 20px auto;
            background-color: rgba;
            padding: 20px;
            border-radius: 8px;
   
}

.payment-container{
	margin-bottom:30px;
	font-size:50px;
	font-family:serif;
	font-weight:bold;
	
}

.payment-container div {
    margin-bottom: 10px;
	font-size:50px;
}

label {
            margin-bottom: 30px;
            font-size: 70px;
            font-family: serif;
            font-weight: bold;
            color: white;
}

input,
select {
    width:100%;
            padding: 28px;
            border: 1px solid #ccc;
            border-radius: 15px;
            box-sizing: border-box;
            font-size: 70px;
            font-family: serif;
            font-weight: bold;
}



.submit_button {
	background-color: #702963;
	width: 100%;
	height:10%;
	 font-size: 100px;
	 font-family: serif;
	 font-weight: bold;
	 border: 1px solid #440f50;
	 border-radius: 15px;
	color:white;
}

.submit_button:hover {
    background-color: #DE3163;
}
.input-fields{
	margin-bottom: 50px;
}
i{
    font-size: 100px;
}
option{
    font-size:20px;
}
header {
            
            font-size: 100px;
            font-weight: bold;
            font-family: serif;
            margin-bottom: 50px;
            color:white;
            padding-top: 60px;
        }
    </style>

<body>
    
    <div class="payment">
    <header>Payments</header>
        <div class="payment-container">

        <!-- <div>
                <label for="">customer name</label>
                <input type="text" name="name">
            </div> -->

      
<form method="POST" action="paymentcreate.php" class="form-close"  > 
<div>
        
<label for="browser">Customer </label><br>
<br>
  <input list="cus_list"  name="cus_detail" id="cus_detail" onkeyup="show_cus_details(this.value)"  >
  <datalist id="cus_list">
   

  <option value="1">Select Customer</option>
               
        <?php
        $query = "SELECT `cus_userID`,	cus_name,	cus_bussinessname FROM `tbl_customer` WHERE cus_status=1 and bus_id=$business_id";
        $conn3 = new mysqli($servername, $username, $password, $dbname);

        $result = $conn3->query($query);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                ?>
                <option value="<?php echo $row['cus_userID']; ?>"><?php echo $row['cus_name'].'  '.$row['cus_userID'].'  '.$row['cus_bussinessname']; ?></option>
                <?php
            }
        }
        ?>
        
 
    </datalist>
</div><br>
<div class="input-fields">

    <label for="loan_id">Loan amount</label><br>
	<br>
    <!-- <select id="loan_id" name="loan_id"></select> -->
    <select id="comboBox" name="comboBox" require></select>
</div><br>

   <div>
       <label for="">Date</label><br>
       <br>
       <select id="date_id" name="date_id" ></select>
       <input type="hidden" value="<?php echo $business_id ?>" require><br>
    <br>
            <div id="net_loan_amt">
                <label for="">  Net Pending Amount</label><br>
                <br>
                <input type="number" name="amount"  id="net_loan_amt1" require>
            </div><br>
            <div>
                <label for="">Balance Amount</label><br>
                <br>
                <input type="number" name="amoumnbnjnbnt" id="balance_amt" require>
            </div><br>
            <div>
                <label for="">Unpaid Amount</label><br>
                <br>
                <input type="number" name="ghfhjg" id="upaid_amt" require>
            </div><br>
            <div>
                <label for="">Installment Amount</label><br>
                <br>
                <input type="number" name="balance" id="install_amt" require>
            </div><br>
            <div>
               <button class="submit_button" type="submit" id="pay" name="pay" value="pay">Pay <i class="fa-solid fa-money-bill"></i></button>
        
            </div><br>

     
    </form>
    </div>
    </div>
   
</body>
<script>
     $(document).ready(
        function(){
            $('.close').click(
                function(){
                    console.log('close clicked');
                    $(this).closest('.payment').hide();
                }
            );

           
        }
);

// $(document).ready(function(){
//         $('#cus_id').change(function(){
//             var customerId = $(this).val();
//             $.ajax({
//                 url: 'login_id.php',
//                 type: 'POST',
//                 data: { customer_id: customerId },
//                 success: function(data){
//                     $('#loan_id').html(data);
//                 }
//             });
//         });
//     });

//     function show_cus_details(str) {
//   if (str == 1) {
//     document.getElementById("net_loan_amt").innerHTML = "select";
//     return;
//   } else {
//     var xmlhttp = new XMLHttpRequest();
//     xmlhttp.onreadystatechange = function() {
//       if (this.readyState == 4 && this.status == 200) {
//         document.getElementById("net_loan_amt").innerHTML = this.responseText;
//         document.getElementById("net_loan_amt1").innerHTML = this.responseText;
//       }
//     };
//     xmlhttp.open("GET", "payment.php?c_type=c_id&cus_id=" + str, true);
//     xmlhttp.send();
//   }
// }


$(document).ready(function(){
            $('#cus_detail').change(function(){
                var rec_cus_id = $(this).val();
                $('#net_loan_amt1').val(0);  
                $.ajax({
                    url: 'paymentcreate.php',
                    type: 'POST',
                    data: {customer_id: rec_cus_id, phase:1},
                    dataType: 'json',
                    success: function(response){
                        // $('#ghghjh').val(response.textData);
                        $('#net_loan_amt1').val(response.textData);                     
                        //    document.getElementById("net_loan_amt").innerHTML = data;
                   //         $('#date').val(response.date);
                          // $('#balance').val(response.installmentAmount);
                           //  $('#ghuhjjh').val(response.textData2);
                        $('#comboBox').html(response.textData3);
                      }
                });
            });
        });


        $(document).ready(function(){
            $('#comboBox').change(function(){
                var rec_loan_id = $(this).val();
            $('#install_amt').val(23);
            $('#balance_amt').val(23);
             $('#upaid_amt').val(23);
             
           
            document.getElementById("pay").disabled = true;
            if(rec_loan_id!='0'){
                // document.getElementById("upaid_amt").value=rec_loan_id;
                $.ajax({
                    url: 'paymentcreate.php',
                    type: 'POST',
                    data: {loan_id: rec_loan_id, phase:2},
                    dataType: 'json',
                    success: function(response){
                        // $('#ghghjh').val(response.textData);
                      //  $('#net_loan_amt1').val(response.textData);                     
                        //    document.getElementById("net_loan_amt").innerHTML = data;
                     //         $('#date').val(response.date);
                // $('#balance').val(response.installmentAmoun
                document.getElementById("pay").disabled = false;
                $('#install_amt').val(response.textData2);
               $('#balance_amt').val(response.textData3);
              $('#upaid_amt').val(response.textData4);
             $('#date_id').html(response.textData);
           
        }
       
                });
            }
            else {
                  
 $('#install_amt').val(0);
 $('#balance_amt').val(0);
 $('#upaid_amt').val(0);

 document.getElementById("pay").disabled = true;
            }
            });
        });

        

//         $.ajax({
//     url: 'fetch_data.php',
//     method: 'POST',
//     data: { selectedValue: selectedValue },
//     dataType: 'json',
//     success: function(response) {
//         $('#textBox').val(response.textData);
//         $('#textBox2').val(response.textData2);
//     },
//     error: function(xhr, status, error) {
//         console.error(xhr.responseText);
//     }
// });

// function stopRefresh(event) {
//             event.preventDefault(); // Prevent the default form submission behavior
//             // Add your custom logic here
//             alert('Form submitted without refreshing the page!');
//         }



</script>

</html>
