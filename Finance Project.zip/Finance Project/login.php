<?php

session_start();
$_SESSION["logged_user_id"] = '';
$_SESSION["active_log_id"] = '';
$_SESSION["business_id"] ='';
$_SESSION["access_id"] = '';
include 'connection.php';
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ipAddress = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ipAddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ipAddress = $_SERVER['REMOTE_ADDR'];
}
if($conn->connect_error) {
    die("connection failed:".$conn->connect_error);
} else {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (!empty($_POST["login_name"]) ) { // Check if both fields are filled
            $user_name = $_POST['login_name'];
            $user_pass = $_POST['login_password'];
            $sql = "CALL sp_validate_user('$user_name','$user_pass', '$ipAddress')";
			//echo "<script>alert('$sql');</script>"; 
            $result = $conn->query($sql);
            if ($result === false) {
                die("Error executing the SQL query: " . $conn->error);
            }

            // Check if any rows were returned
            if ($result->num_rows > 0) {
                // Fetching results
                $rows = $result->fetch_all(MYSQLI_ASSOC);
                foreach ($rows as $row) {
                    $_SESSION["logged_user_id"] = $row['_user_id'];
                    $_SESSION["active_log_id"] = $row['_log_id'];
                    $_SESSION["business_id"] = $row['_bus_id'];
                    $_SESSION["access_id"] = $row['_access_id'];
                    
                    header("Location: menubar.php");
                     // Always exit after redirecting
                }
            } 
                
            }
       
        }
    }

?>

<html>
<link rel="shortcut icon" type="x-icon" href="logo.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
	body{
background-color: 240046;
	}
.section{
	background-color:6f2dbd;
	width:83%;
	height:85%;
	margin-top:150px ;
	margin-left: 40px;
	padding-top:80px;
	padding-left: 50px;
	padding-right: 40px;
	border-radius: 20px;
	box-shadow: 5px 10px;
}
input[type="email"], input[type="password"], input[type="text"]{
	
	width:100%;
	height: 10%;
	 border: 1px solid #ccc;
    border-radius: 15px;
	font-size: 50px;
	font-family: serif;
	 font-weight: bold;
	margin-bottom: 80px;
}
input[type="checkbox"]{
	
	width:10%;
	height:3%;
	font-size: 50px;
	font-family: serif;
	font-weight: bold;
	margin-bottom: 30px;
}
button{
	background-color: #702963;
	width:100%;
	height:10%;
	 font-size: 75px;
	 font-family: serif;
	 font-weight: bold;
	 border: 1px solid #440f50;
	 border-radius: 15px;
	margin-top: 100px;
     color:white;
}
button:hover{
	background-color: #DE3163;
}

label{
	font-size: 70px;
	font-family: serif;
	 font-weight: bold;
	 color:white;
}
header{
	font-size: 100px;
	font-family: serif;
	font-weight: bold;
	margin-bottom: 50px;
	margin-left:270px;
	color: white;
}
span{
	font-size: 70px;
	font-weight: bold;
	bottom: 10%;
	color:white;
}
img{
	width:35%;
	height: 15%;
	background-color: white;
	clip-path: circle();
	margin-left: 250px;
	margin-bottom: 20px;
	padding:10px;
}
i{
	font-size: 70px;
	
}

</style>
<body>
<div class="section">
<img src="logo.png" >
	<div>
		<header>Login</header>
		</div>
	<form action="login.php" method="POST">
<label>Username </label><br>
<br>
<input type="email" name="login_name"><br>
<br>
<label>Password </label><br>
<br>
<input type="password"  id="myInput" name="login_password"><br>
<br>
<input type="checkbox" onclick="myFunction()"> <span>Show-Password</span> <br>
<br>
<button type="submit">Login <i class="fa-solid fa-right-to-bracket"></i></button>
</form>
</div>
</body>
<script>
	function myFunction() {
  var myInput = document.getElementById("myInput");
  if (myInput.type === "password") {
    myInput.type = "text";
  } else {
    myInput.type = input="password";
  }
	}
</script>
</html>