<html>
<style>
.group{
	background-color:ffb703;
	margin-right:190px;
	margin-left:200px;
	margin-top:10px;
	
	padding-left:190px;
	padding-right:400px;
	padding-top:30px;
	padding-bottom:10px;
}
.section, input{
	padding-left:0px;
	padding-right:300px;
	padding-top:10px;
	padding-bottom:10px;
	 border: 1px solid #ccc;
    border-radius: 5px;
}
button{
	background-color:00f5d4;
	padding-top:5px;
	padding-bottom:5px;
	padding-left:10px;
	padding-right:10px;
	 border-radius: 5px;
}
</style>
<body>
<div class="group">
<label>NAME</label><br>
<br>
<input type="text" placeholder="NAME" ><br>
<br>
<label>LOAN-AMOUNT</label><br>
<br>
<input type="text" placeholder="LOAN-AMOUNT"><br>
<br>
<label>HANDLING-AMOUNT</label><br>
<br>
<input type="number" placeholder="HANDLING-AMOUNT"><br>
<br>
<label>COMMISSION-PERCENTAGE</label><br>
<br>
<input type="number" placeholder="COMMISSION-PERCENTAGE"><br>
<br>
<label>REPAYMENT-SCHEDULE</label><br>
<br>
<input type="text" placeholder="REPAYMENT-SCHEDULE"><br>
<br>
<button type="submit">PROCESS</button><br>
<br>
</div>
</body>
</html>