<?php
session_start();
include("connection.php");

$conn1= new mysqli($servername, $username, $password, $dbname);

if(isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])){
    $logged_user_id=$_SESSION["logged_user_id"];
    $active_log_id=$_SESSION["active_log_id"];
    $business_id=$_SESSION["business_id"];
   $access_id =$_SESSION["access_id"] ;
    if ($active_log_id!=0) {
    
        $sql = "CALL sp_validate_log('$active_log_id')";
        
        $result = $conn->query($sql);
        if ($result === false) {
           die("Error executing the SQL query: " . $conn->error);
       }
      
        if($result->num_rows > 0){
            // Fetching results
            $rows = $result->fetch_all(MYSQLI_ASSOC);
           
             foreach ($rows as $row) {
             $log_status= $row['_log_status'];
             
             
              
         
             }
            
        }
       }
   
        if ($log_status==0){
           header("Location: login.php");
   
        }
        else{
           $_SESSION["logged_user_id"] =$logged_user_id;
           $_SESSION["active_log_id"] = $active_log_id;
          $_SESSION["access_id"] = $access_id ;
           $_SESSION["business_id"]=$business_id; 
        }
}
else{
    header("Location: login.php");
}


$_add_name=$_POST["addon_value"];
$_addon_type=$_POST["addon_type"];
echo $_add_name;
echo $_addon_type;
$sql="CALL sp_create_addons('$_add_name','$_addon_type',$logged_user_id, $business_id)";
echo $sql;
$result = $conn1->query($sql);
if(!$result){
    echo "<script>alert('Error!!')</script>";
} else{
    header("Location:menubar.php");
}

?>