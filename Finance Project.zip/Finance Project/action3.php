<?php
session_start();
include "connection.php";
$conn = new mysqli($servername, $username, $password, $dbname);
$conn1 = new mysqli($servername, $username, $password, $dbname);
$conn5 = new mysqli($servername, $username, $password, $dbname);

if (isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])) {
    $logged_user_id = $_SESSION["logged_user_id"];
    $active_log_id = $_SESSION["active_log_id"];
    $business_id = $_SESSION["business_id"];
    
    $access_id = $_SESSION["access_id"];
    
    if ($active_log_id != 0) {
        $sql = "CALL sp_validate_log('$active_log_id')";
        $result = $conn->query($sql);
        if ($result === false) {
            die("Error executing the SQL query: " . $conn->error);
        }
        if ($result->num_rows > 0) {
            $rows = $result->fetch_all(MYSQLI_ASSOC);
            foreach ($rows as $row) {
                $log_status = $row['_log_status'];
            }
        }
    }
    if ($log_status == 0) {
        header("Location: login.php");
    } else {
        $_SESSION["logged_user_id"] = $logged_user_id;
        $_SESSION["active_log_id"] = $active_log_id;
        $_SESSION["access_id"] = $access_id;
        $_SESSION["business_id"] = $business_id;
       
    }
}

  
if (isset($_POST['submit'])){
    $_user_id=$_POST['user_id'];
    $business_id=$_POST['business_id'];
    echo $_user_id;
    
    $sql="CALL sp_day_close($_user_id, $business_id)";
    echo $sql;


    
    $conn6 = new mysqli($servername, $username, $password, $dbname);
    $result = $conn6->query($sql);
    if (!$result) {
        echo "<script>alert('Error!!')</script>";
    } else {
        echo "<script>alert('loan approved successfully!')</script>";
    }
} 

    ?>
