<?php
session_start();
include("connection.php");

?>

<html>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    option{
            font-size:20px;
         }

        .container {
            width: 80%;
            margin: 20px auto;
            background-color: rgba;
            padding: 20px;
            border-radius: 8px;
           
        }

        .form {
            margin-bottom: 20px;
        }

        header {
            font-size: 60px;
            font-weight: bold;
            font-family: serif;
            margin-bottom: 70px;
            color: white;
        }

        .input-fields {
            margin-bottom: 50px;
        }

        label {
            display: block;
            margin-bottom: 30px;
            font-size: 50px;
            font-family: serif;
            font-weight: bold;
            color: white;
        }
       select{
        width:100%;
            padding: 28px;
            border: 1px solid #ccc;
            border-radius: 15px;
            box-sizing: border-box;
            font-size: 50px;
            font-family: serif;
            font-weight: bold;
       }
        input
        {
            width:100%;
            padding: 28px;
            border: 1px solid #ccc;
            border-radius: 15px;
            box-sizing: border-box;
            font-size:50px;
            font-family: serif;
            font-weight: bold;

        }
         
        .create-btn {
            background-color: #702963;
	width:100%;
	height:10%;
	 font-size: 75px;
	 font-family: serif;
	 font-weight: bold;
	 border: 1px solid #440f50;
	 border-radius: 15px;
	
     color:white;
        }

        .create-btn:hover {
            background-color: #DE3163;
        }
        i{
            font-size: 70px;
        }
        header{
            font-size:100px;
            font-family:serif;
            font-weight:bold;
        }
</style>		
<body>
<div class="container" >
<div class="form first">
<header>User Details</header>
<form action="usercreator.php" method="POST">
<div class="fields">
<div class="input-fields">
<label>Name</label>
<input type="text" name="user-name">
</div>
<div class="input-fields">
<label>Username</label>
<input type="email" name="login_name">
</div>
<div class="input-fields">
<label>Password</label>
<input type="password" name="login_password">
</div>
<div class="input-fields">
<label>Phone-Number</label>
<input type="number" name="user_phonenumber">
</div>
<div class="input-fields">
<label>Whatsapp-Number</label>
<input type="number" name="user_whatsappnumber">
</div>
<div class="input-fields">
<?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='gender' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="Gender">Gender</label>
                   <select  name="user_gender" id="gender">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
                       
                   </select>
               </div>
               </div>
<div class="input-fields">
<label>Address</label>
<input type="text" name="user_address">
</div>
<div class="input-fields">
<?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='City' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="City">City</label>
                   <select  name="user_city" id="City">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
                       
                   </select>
               </div>
               </div>
<div class="input-fields">
<?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='State' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="State">State</label>
                   <select  name="user_state" id="State">
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
                       
                   </select>
               </div>
               </div>
<div class="input-fields">
<label>Pincode</label>
<input type="text" name="user_pincode">
</div>
<div class="input-fields">
<?php 
    $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='Proof' AND addon_status=1;";
    $result = $conn->query($query);
   
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
?>
               <div class="input-fields">
                   <label for="user_proof_type">Proof-Type</label>
                   <select  name="user_proof_type" id="Proof" >
                   <?php 
  foreach ($row as $itemlist) {
 
  ?>
    <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
    <?php 
    }
   ?>
                       
                   </select>
               </div>
               </div>
<div class="input-fields">
<label>Proof-Number</label>
<input type="text" name="user_proof" >
</div>
<div class="input-fields">
<button type="submit" class="create-btn">Create <i class="fa-solid fa-circle-plus"></i></button>
</div>
</div>
</div>
</div>
</form>
</div>
</body>
</html>