<?php
session_start();
include "connection.php";
$conn = new mysqli($servername, $username, $password, $dbname);
$conn1 = new mysqli($servername, $username, $password, $dbname);
$conn3 = new mysqli($servername, $username, $password, $dbname);
$conn4 = new mysqli($servername, $username, $password, $dbname);
$conn5 = new mysqli($servername, $username, $password, $dbname);

if (isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])) {
    $logged_user_id = $_SESSION["logged_user_id"];
    $active_log_id = $_SESSION["active_log_id"];
    $business_id = $_SESSION["business_id"];
    
    $access_id = $_SESSION["access_id"];
    
    if ($active_log_id != 0) {
        $sql = "CALL sp_validate_log('$active_log_id')";
        $result = $conn->query($sql);
        if ($result === false) {
            die("Error executing the SQL query: " . $conn->error);
        }
        if ($result->num_rows > 0) {
            $rows = $result->fetch_all(MYSQLI_ASSOC);
            foreach ($rows as $row) {
                $log_status = $row['_log_status'];
            }
        }
    }
    if ($log_status == 0) {
        header("Location: login.php");
    } else {
        $_SESSION["logged_user_id"] = $logged_user_id;
        $_SESSION["active_log_id"] = $active_log_id;
        $_SESSION["access_id"] = $access_id;
        $_SESSION["business_id"] = $business_id;
        
        if (isset($_POST['submit'])) {
            $_sf_id=$_POST["sf_id"];
            $_area_id=$_POST["cus_area"];
            $_date=date("Y-m-d");
            
            $sql = "CALL sp_allotment($_sf_id, $_area_id, '$_date', $business_id)";
            
            $conn1 = new mysqli($servername, $username, $password, $dbname);
$result = $conn1->query($sql);
if(!$result)
{
echo "<script>alert('Error!!')</script>";
}
else
{
    
}
}
   }
        }




?>
<html>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <header>Alotment</header>
    <style>
      .input-fields{
        margin-top:100px;
        margin-bottom:30px;
      
      }
      header{
        font-size:100px;
        color:white;
        font-weight:bold;
        font-family:serif;
      }
       select{
        width:100%;
	height: 10%;
	 border: 1px solid #ccc;
    border-radius: 15px;
	font-size: 60px;
	font-family: serif;
	 font-weight: bold;
	margin-bottom: 80px;
       }
       button{
        background-color: #8B004B;
        width:100%;
	height: 10%;
	 border: 1px solid #ccc;
    border-radius: 15px;
	font-size: 70px;
	font-family: serif;
	 font-weight: bold;
   color:white;
	margin-bottom: 80px;
       }
       button:hover{
        background-color: #DE3163;
       }
       label{
        font-size: 70px;
        font-weight:bold;
        font-family:serif;
        color:white;
       }
       option{
        font-size: 30px;
       }
       i{
	font-size: 70px;
	color:white;
}
        </style>

<body>
    <form method="POST" action="allotment.php">
<div class="input-fields">
      <?php 
              
               $query ="SELECT user_id ,user_name FROM tbl_user WHERE  user_status=1 AND access_id=1 AND bus_id=$business_id;";
            // $query="SELECT user_id ,user_name FROM tbl_user WHERE  user_status=1 AND access_id=4 SELECT * from tbl_addons INNER JOIN tbl_allotment ON tbl_addons.addon_id!=tbl_allotment.area_id WHERE tbl_addons.addon_type='Area'";
              $conn5 = new mysqli($servername, $username, $password, $dbname);
              $result = $conn5->query($query);
   
             if($result->num_rows> 0){
                $row= mysqli_fetch_all($result, MYSQLI_ASSOC);

                      ?>
               
                   <label >Staff</label><br>
                   <br>
                   <select  name="sf_id" id="sf_id">
                   <?php 
                     foreach ($row as $itemlist) {
 
                      ?>
                        <option value=<?php echo  $itemlist['user_id']; ?>><?php echo  $itemlist['user_name']; ?> </option>
                         <?php 
                    }    }
                      ?></select>
 </div>
 <div class="input-fields">
      <?php 
              $query ="SELECT addon_id,addon_name FROM tbl_addons`INNER JOIN tbl_allotment ON tbl_addons.addon_id!=tbl_allotment.area_id WHERE `addon_type='Area';";
            
              $conn3 = new mysqli($servername, $username, $password, $dbname);
               $result = $conn3->query($query);
               if($result->num_rows> 0){
                $row= mysqli_fetch_all($result, MYSQLI_ASSOC);

                      ?>
               
                   <label for="Area">Area</label>
                   <select  name="cus_area" id="cus_area">
                   <?php 
                     foreach ($row as $itemlist) {
 
                      ?>
                        <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
                         <?php 
                    }  ?>

                    </select><?php 
               
                }
       

else{
    $query ="SELECT addon_id,addon_name FROM tbl_addons WHERE addon_type='Area';";
            
    $conn4 = new mysqli($servername, $username, $password, $dbname);

     $result = $conn4->query($query);
    if($result->num_rows> 0){
      $row= mysqli_fetch_all($result, MYSQLI_ASSOC);

            ?>
     
         <label for="Area">Area</label><br>
         <br>
         <select  name="cus_area" id="cus_area">
         <?php 
           foreach ($row as $itemlist) {

            ?>
              <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
               <?php 
          }  ?>

          </select><?php 
      }



}

?></div> <br>
<br>
   
               
<button type="submit" name="submit" value="Add" class="add">Add <i class="fa-solid fa-square-plus"></i></button>
                </body>
                </html>