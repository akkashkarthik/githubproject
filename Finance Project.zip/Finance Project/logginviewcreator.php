<?php
session_start();
$_log_id=$_SESSION["logged_user_id"];
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "vidyabha_col_agent";
$conn = new mysqli($servername, $username, $password, $db_name);
if($conn->connect_error){
    die("Connection failed".$conn->connect_error);
}
else{
    $query ="SELECT cus_id,loan_amt,hand_amt,(SELECT addon_name from tbl_addons where addon_id=due_period)as d_id,(SELECT addon_name from tbl_addons where addon_id=due_period_type)as dp_id,payment_duration,due_amt,tbl_loans.loan_id, loan_status FROM tbl_loans where loan_status=0";
    $result = $conn->query($query);
    if($result->num_rows > 0){
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);

        if (isset($_POST['submit'])){
            $_loan_id=$_POST['loan_id'];
            $sql="CALL sp_duration_creator($_loan_id, $_log_id)";
            $result = $conn->query($sql);
            if (!$result) {
                echo "<script>alert('Error!!')</script>";
            } else {
                echo "<script>alert('loan approved successfully!')</script>";
            }
        }

        ?>




        <html>
        <head>
            <style>
                table {
                    width: 150%;
                    height: 80%;
                    font-size:70px;
                    font-family: serif;
                    font-weight: bold;
                    gap:5px;
                    margin-top:150px;
                    border-collapse: collapse;
                    background-color:#8900f2;
                    color:white;
                    overflow: auto;
                    white-space: nowrap;
                }

                th, td {
                    padding: 100px;
                    text-align: left;
                    border-bottom: 1px solid black;
                    border-color: black;
                    overflow: auto;
                   white-space: nowrap;
                }

                th {
                    background-color:5a189a ;
                    color: white;
                    overflow: auto;
                    white-space: nowrap;
                }

                .details {
                    display: none;
                }
                .submit {
                    width: 120%;
                    height: 50%;
                    font-size:70px;
                    font-family: serif;
                    font-weight: bold;
                    padding-bottom: 10px;
                    background-color: #007f5f;
                    color: white;

                }

            </style>
        </head>
        <body>



        <table style="width:100%">
            <tr>
                <th>Customer Id</th>
                <th>Loan Amount</th>
                <th>Handling Amount</th>
                <th>Due Period</th>
                <th>Period Type</th>
                <th>Payment Duration</th>
                <th>Due Amount</th>
                <th>Action</th>
            </tr>
            <?php
            foreach ($row as $itemlist) {
                ?>
                <tr>
                    <td><?php echo  $itemlist['cus_id']; ?></td>
                    <td><?php echo  $itemlist['loan_amt']; ?></td>
                    <td><?php echo  $itemlist['hand_amt']; ?></td>
                    <td><?php echo  $itemlist['d_id']; ?></td>
                    <td><?php echo  $itemlist['dp_id']; ?></td>
                    <td><?php echo  $itemlist['payment_duration']; ?></td>
                    <td><?php echo  $itemlist['due_amt']; ?></td>
                    <td>
                        <form method="POST" action="tableview.php" class="form-close">
                            <input type="hidden" name="loan_id" value="<?php echo  $itemlist['loan_id'];?>"> 
                            <button class="submit" id="approvel_id" name="submit">Approved</button>
                        </form> 
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>
    <?php
    }
}
?>
</body>
</html>