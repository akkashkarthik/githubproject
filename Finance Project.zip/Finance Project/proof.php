<html>
<style>
.section{
	background-color:ffb703;
	margin-right:270px;
	margin-left:300px;
	margin-top:90px;
	padding-left:190px;
	padding-right:300px;
	padding-top:50px;
	padding-bottom:50px;
}
input{
	padding-left:0px;
	padding-right:100px;
	padding-top:10px;
	padding-bottom:10px;
	 border: 1px solid #ccc;
    border-radius: 5px;
}
button{
	background-color:00f5d4;
	padding-top:5px;
	padding-bottom:5px;
	padding-left:10px;
	padding-right:10px;
	 border-radius: 5px;
}
</style>
<body>
<div class="section">
<label>PROOF-TYPE</label><br>
<br>
<input list="brows" name="proof-t" id="proof">
<datalist id="brows">
    <option value="AADHAR">
    <option value="PAN">
    <option value="LISCENCE">
  </datalist><br>
<br>
<label>PROOF-NUMBER</label><br>
<br>
<input type="number" placeholder="PROOF-NUMBER" ><br>
<br>
<button type="submit">ADD</button>
</div>
</body>
</html>