<?php
session_start();
include("connection.php");
?>
<html>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
body {font-family: Arial;}

/* Style the tab */
.tab {
    width: 100%;
    height: 15%;
   align-items: center;
  margin-top:150px;
  overflow: hidden;
  background-color: #3c096c;
  overflow-x: scroll;
  overflow-y: hidden;
  white-space: nowrap;
  scroll-snap-type: x mandatory;
  
}

/* Style the buttons inside the tab */
.tab button {
   
    height: 15%;
  background-color:#3c096c;
  border: none;
  padding-top: 80px;
  padding-left: 30px;
  padding-right: 10px;
  outline: none;
  color: white;
  font-size: 65px;
 font-family: serif;
 font-weight: bold;
 transition: 0.5s;
 cursor: pointer;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #3c096c;
  height: 30%;
  padding-top: 60px;
  padding-left: 30px;
  padding-right: 10px;
   
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #3c096c;
  height: 30%;
  padding-top: 60px;
  padding-left: 30px;
  padding-right: 10px;
}

/* Style the tab content */
.tabcontent {
  padding-top: 200px;
  padding-left:180px;
  margin-top: 50px;
  background-color: #3c096c;  
  display: none;
  width: 99%;
  height: 70%;
  font-size: 50px;
  font-family: serif;
 font-weight: bold;
}
input{
	width: 60%;
    height: 15%;
	 border: 1px solid #ccc;
    border-radius: 15px;
    font-size: 50px;
    border-radius: 20px;
}
.Createbtn5{
	background-color: #702963;
	width:60%;
	height:15%;
	 font-size: 75px;
	 font-family: serif;
	 font-weight: bold;
	 border: 1px solid #440f50;
	 border-radius: 15px;
	margin-top: 100px;
     color:white;
}
.Createbtn5:hover{
    background-color: #DE3163;
}
label{
    font-size: 90px;
    color: white;
}
i{
    font-size: 70px;
}
</style>
<body>
<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'gender')">Gender</button>
  <button class="tablinks" onclick="openCity(event, 'city')">City</button>
  <button class="tablinks" onclick="openCity(event, 'state')">State</button>
  <button class="tablinks" onclick="openCity(event, 'proof')">Proof</button>
  <button class="tablinks" onclick="openCity(event, 'Area')">Area</button>
</div>

<div id="gender" class="tabcontent">
        <form action="addons_creator.php"method="POST">
            <input type="hidden" name="addon_type" value="Gender" id="gender">
        <div class="container6">
            <div class="form6">
            </div>
            <div class="fields6">
                <div class="input-fields6">
                    <label>Gender</label><br>
                    <br>
                    <input type="text" name="addon_value"  ><br>
                    <br>
                </div>

                <button type="submit" class="Createbtn5">Add <i class="fa-sharp fa-solid fa-venus-mars"></i></button>
        </div>
        </div>
        </div>
        </form>
</div>
        <div id="city" class="tabcontent">
            <form action="addons_creator.php"method="POST">
                <input type="hidden" name="addon_type" value="City" id="city">
            <div class="container6">
                <div class="form6">
                </div>
                <div class="fields6">
                    <div class="input-fields6">
                        <label>City</label><br>
                        <br>
                        <input type="text" name="addon_value"  ><br>
                        <br>
                    </div>

                    <button type="submit" class="Createbtn5">Add <i class="fa-solid fa-city"></i><i class="fa-sharp fa-solid fa-octagon-plus"></i></button>
            </div>
            </div>
            </div>
            </form>
     </div>
            <div id="state" class="tabcontent">
                    <form action="addons_creator.php"method="POST">
                        <input type="hidden" name="addon_type" value="State" id="state">
                    <div class="container6">
                        <div class="form6">
                        </div>
                        <div class="fields6">
                            <div class="input-fields6">
                                <label>State</label><br>
                                <br>
                                <input type="text" name="addon_value" ><br>
                                <br>
                            </div>

                            <button type="submit" class="Createbtn5">Add <i class="fa-solid fa-flag"></i></button>
                    </div>
                    </div>
                    </div>
                    </form>
            </div>
            <div id="proof" class="tabcontent">
                    <form action="addons_creator.php"method="POST">
                        <input type="hidden" name="addon_type" value="Proof" id="proof">
                    <div class="container6">
                        <div class="form6">
                        </div>
                        <div class="fields6">
                            <div class="input-fields6">
                                <label>Proof</label><br>
                                <br>
                                <input type="text" name="addon_value" ><br>
                                <br>
                            </div>

                            <button type="submit" class="Createbtn5">Add <i class="fa-solid fa-address-card"></i></button>
                    </div>
                    </div>
                    </div>
                    </form>    
            </div>
            <div id="Area" class="tabcontent">
                    <form action="addons_creator.php"method="POST">
                        <input type="hidden" name="addon_type" value="Area" id="area">
                    <div class="container6">
                        <div class="form6">
                        </div>
                        <div class="fields6">
                            <div class="input-fields6">
                                <label>Area</label><br>
                                <br>
                                <input type="text" name="addon_value" ><br>
                                <br>
                            </div>

                            <button type="submit" class="Createbtn5">Add <i class="fa-solid fa-building"></i></button>
                    </div>
                    </div>
                    </div>
                    </form>    
            </div>

<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>
   
</body>
</html> 

