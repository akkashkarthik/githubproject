<style>
    .btn {
    display: grid;
    grid-template-columns: repeat(3, 2fr);
  background-color: #blue;   
  border:none;
  height: 100%;
  
}
/*.btn1 {
    display: flex;
  background-color: #f1f1f1;  
  border:none; 
  height: 30%;
}
.btn2{
    display: flex;
  background-color: #f1f1f1;
  height: 30%;
  border:none;
}
.btn3{
    display: flex;
    height: 30%;
    border:none;
} */
.cls{
   width: 100%;
   height: 80%;
   border: none;
   border-bottom: none;
   background-color: #240046; 
   color: white;
   font-size: 43px;
   font-weight: bold;
   
}
.bsect{
    width: 100%;
   height: 25%;
    border: none;
    
    
}


 /* .btn4{ 
    display: flex;
  background-color: #f1f1f1; 
  height: 20%;
  border:none;
} */
i{
    font-size: 100px;
    color:white;
}
.cls:hover{
    background-color: #9d4edd;
    color:black;
}
i:hover{
    color:black;
}
.nav__text:hover{
    color:black;
}
.nav__link:hover{
    color:black;
}
.clss{
    width: 300%;
   height: 100%;
   border: none;
   background-color: #240046; 
   color: white;
   font-size: 43px;
   font-weight: bold;
}
.clss:hover{
    background-color: #9d4edd;
    color:black;
}
img{
    width:70%;
    height:50%;
    margin-top:300px;
    margin-left: 50px;
    background-color: white;
    clip-path: circle();
    padding:50px 100px;
}

</style>
<div class="bsect">
            <div class="btn" >
                
                <button class="cls" id="user"><i class="fa-sharp fa-solid fa-user"></i><br><br>User</button>
                
                
                <button class="cls " id="customer"><i class="fa-sharp fa-solid fa-users"></i><br><br>Customer</button>
               
                
                <button class="cls " id="dayclose"><i class="fa-regular fa-calendar-days"></i><br><br>Day Close</button>
                
            </div>

            <div class="btn">
               
                <button class="cls " id="setting"> <i class="fa-solid fa-gear"></i><br><br>Setting</button>
                
                
                <button class="cls" ><i class="fa-solid fa-sack-dollar"></i><br><br>Loan Approve</button>
                
               
                <button class="cls " id="line"><i class="fa-brands fa-elementor"></i><br><br>Line Collection</button>
                
            </div>
            <div class="btn">
               
                <button class="cls " ><i class="fa-solid fa-circle-user"></i><br><br>Staff Wise</button>
                
              
                <button class="cls " id="allotment"><i class="fa-solid fa-building-user"></i><br><br>Allotment</button>
                
                <button class="cls " id="loanview"><i class="fa-solid fa-magnifying-glass-dollar"></i><br><br>Loan View</button>
                
            </div>
            <div class="btn">
                
                <button class="cls " id="customerview"><i class="fa-solid fa-users-rectangle"></i><br><br>Customer view</button>
                
                <button class="cls " id="userview"><i class="fa-solid fa-clipboard-user"></i><br><br>User view</button>
                
                <button class="cls " id="addloan"><i class="fa-solid fa-file-invoice-dollar"></i><br><br>Additional Loan</button>
            
               
            </div>
            
            <div class="btn">

                <button class="cls " id="ledger"><i class="fa-solid fa-table-list"></i><br><br>Ledger</button>
                
                <button class="cls " id="collection"><i class="fa-solid fa-coins"></i><br><br>Collection</button>

                <button class="cls "><i class="fa-solid fa-table-cells"></i><br><br>Ledger view</button>
                
            </div>
           
    </div>
    <script>
    $(document).ready(function(){
       $('#payment').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'loanpayments.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });

    $(document).ready(function(){
       $('#loan').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'loan.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#user').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'user.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#customer').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'customer.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#setting').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'setting.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#collection').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'collection.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#line').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'line.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#loanview').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'loanview.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
</script>
<script>
function logout(){
  window.location.href ="login.php";
}
$(document).ready(function(){
       $('#payview').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'paymentview.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#userview').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'userview.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#customerview').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'customerview.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#addloan').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'additionalloan.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#loanapprove').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'loanapprove.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#ledger').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'ledger2.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#allotment').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'allotment.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#dayclose').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'dayclose.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
</script>
<script>
    let popup=document.getElementById("popup");
           function openPopup(){
            popup.classList.add("open-popup");
           }
</script>
<script>
function logout(){
  window.location.href ="login.php";
}
</script>