<html>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
 <style>
    body {
    margin: 0 0 55px 0;
    background-color:240046;
}

.nav {
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 140px;
    box-shadow: 0 0 3px rgba(0, 0, 0, 0.2);
    background-color:3c096c;
    color:white;
    display: flex;
    overflow-x: auto;
}

.nav__link {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex-grow: 1;
    min-width: 50px;
    overflow: hidden;
    white-space: nowrap;
    font-family: sans-serif;
    font-size: 13px;
    color:e0aaff;
    text-decoration: none;
    -webkit-tap-highlight-color: transparent;
    transition: background-color 0.1s ease-in-out;
}

.nav__link:hover {
    background-color:5a189a;
}

.nav__link{
    color:fffcf2;
}

i {
    font-size: 70px;
}
.nav__text{
  font-size: 30;
  font-family: serif;
  font-weight: bold;
}
#popup {
  width:90%;
  height:80%;
        display:none;
        position: absolute;
        top: 45%;
        left: 30%;
        transform: translate(-50%, -50%);
        background-color: 6f2dbd;
        padding: 5px;
        border: 2px solid #000;
        z-index: 1;
        visibility: visible;
        padding-bottom: 130px;
        margin-left:200px;
        padding-right:0px;
        margin-right:600px;
        overflow-x: hidden;
        overflow-y: scroll;
        scroll-snap-type: y mandatory;
        scroll-snap-align: start none;
        scroll-margin-block-start: 20px;
}
  }
    .open-popup{
    visibility: visible;
    top: 50%;
    transform: translate(-50%, -50%) scale(1);
}
.fa-sharp.fa-regular.fa-xmark{
  float:right;
  font-size:40px;
  font-weight: bold;
}
</style>
  <body>
  <nav class="nav">
  <a href="#" class="nav__link" id="payment">
  <i class="fa-solid fa-sack-dollar"></i>
    <span class="nav__text">PAYMENT</span>
  </a>
  <a href="#" class="nav__link nav__link--active" id="loan">
  <i class="fa-solid fa-coins"></i>
    <span class="nav__text">LOAN</span>
  </a>
  <a href="#" class="nav__link" id=user>
  <i class="fa-sharp fa-solid fa-user"></i>
    <span class="nav__text">USER</span>
  </a>
  <a href="#" class="nav__link" id="customer">
  <i class="fa-sharp fa-solid fa-users"></i>
    <span class="nav__text">CUSTOMER</span>
  </a>
  <a href="#" class="nav__link" onclick="logout()">
  <i class="fa-sharp fa-solid fa-power-off"></i>
    <span class="nav__text">LOGOUT</span>
  </a>
</nav>

<div class="popup" id="popup">
</div>

  <script>
    $(document).ready(function(){
       $('#payment').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'loanpayments.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });

    $(document).ready(function(){
       $('#loan').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'loan.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#user').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'user.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
   $(document).ready(function(){
       $('#customer').click(function(){
           console.log('button clicked');
           $.ajax({
               url: 'customer.php',
               type: 'GET',
               dataType: 'html',
               success: function(response) {
                   $('#popup').html(response);
                   $('#popup').show();
               },
               error: function(xhr, status, error) {
                   console.error(xhr.responseText);
               }
           });
       });
   });
  
  
   
</script>
<script>
function logout(){
  window.location.href ="login.php";
}
</script>
</body>
</html>