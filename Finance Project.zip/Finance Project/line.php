<?php
session_start();
include "connection.php";
$conn = new mysqli($servername, $username, $password, $dbname);
$conn1 = new mysqli($servername, $username, $password, $dbname);
if (isset($_SESSION["logged_user_id"]) && !empty($_SESSION["logged_user_id"])) {
    $logged_user_id = $_SESSION["logged_user_id"];
    $active_log_id = $_SESSION["active_log_id"];
    $business_id = $_SESSION["business_id"];
    
    $access_id = $_SESSION["access_id"];
    
    if ($active_log_id != 0) {
        $sql = "CALL sp_validate_log('$active_log_id')";
        $result = $conn->query($sql);
        if ($result === false) {
            die("Error executing the SQL query: " . $conn->error);
        }
        if ($result->num_rows > 0) {
            $rows = $result->fetch_all(MYSQLI_ASSOC);
            foreach ($rows as $row) {
                $log_status = $row['_log_status'];
            }
        }
    }
    if ($log_status == 0) {
        header("Location: login.php");
    } else {
        $_SESSION["logged_user_id"] = $logged_user_id;
        $_SESSION["active_log_id"] = $active_log_id;
        $_SESSION["access_id"] = $access_id;
        $_SESSION["business_id"] = $business_id;
       
    }
}


?>

<!DOCTYPE html>
<html>
    <header>Line Collection</header><br>
    <br>
    <style>
        header{
            font-size:100px;
            font-weight:bold;
            font-family:serif;
            color:white;
        }
        select{
            width:100%;
	height: 10%;
	 border: 1px solid #ccc;
    border-radius: 15px;
	font-size: 70px;
	font-family: serif;
	 font-weight: bold;
	margin-bottom: 80px;
        }
        label{
            font-size:80px;
            font-weight:bold;
            font-family:serif;
            color:white;
        }
        option{
            font-size:20px;
        }
    </style>
    
  <body>
  <?php 
             
        $query ="SELECT `addon_id`,addon_name FROM `tbl_addons` WHERE `addon_type`='Area' AND addon_status=1 AND bus_id=$business_id;";
        $conn3 = new mysqli($servername, $username, $password, $dbname);
        $result = $conn3->query($query);
         if($result->num_rows> 0){
          $row= mysqli_fetch_all($result, MYSQLI_ASSOC);
          ?>
              <input type="hidden" value="<?php echo $business_id ?>" id="b_id">
              <label for="Area">Area</label><br>
              <br>
               <select  name="cus_area" id="area" onchange=showUser(this.value)>
               <option value="0">select area</option>

                  <?php 
                    foreach ($row as $itemlist) {
                   ?>
          <option value=<?php echo  $itemlist['addon_id']; ?>><?php echo  $itemlist['addon_name']; ?> </option>
                 <?php 
                    }    }
                    ?></select>
  
<div id="area_result"></div>
</body>
<script>
function showUser(str) {
  if (str=="") {
    document.getElementById("area_result").innerHTML="";
   return;
   } 
  var b_id=document.getElementById("b_id").value
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("area_result").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","action.php?d_type=area&b_id="+b_id+"&line_id="+str,true);
  xmlhttp.send();
} 
</script>

</html>