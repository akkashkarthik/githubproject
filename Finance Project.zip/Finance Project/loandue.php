<html>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}
.container {
    width: 70%;
    margin: 80px auto;
	
	
}

.fields {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}


.input-fields {
    width: 40%;
    margin-bottom: 15px;
}

.input-fields label {
    display: block;
    margin-bottom: 5px;
	font-family:serif;
}
.input-fields input, 
.input-fields datalist{
    width: 100%;
    padding: 8px;
	border: 1px solid #ccc;
    border-radius: 5px;
	font-family:serif;
    font-size: medium;
}
input[type="text"]{
	padding-right:10px;
}

.create-btn {
    background-color: 00f5d4;
    width: 100%;
    padding-left: 15px;
	 padding-top: 10px;
	  padding-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
	font-family:serif;
	margin-top:24px;
	margin-left:1px;
}

.form {
    display: none;
}

.form.first {
    display: block;
}

.form header {
    
    padding: 10px;
    margin-bottom: 20px;
	margin-left: 198px;
}

.form.second header {
    background-color: ;
    padding: 10px;
    margin-bottom: 10px;
}
.form {
    width: 400px;
    margin: 5 auto;
	padding-top: 40px;
    padding-left: 40px;
	padding-right:30px;
	padding-bottom: 20px;
    background-color: c1121f;
    border-radius: 5px;
    margin-right:300px;
}
label{
    font-size: medium;
    font-weight: bold;
}

</style>		
<body>
<div class="container" >
<div class="form first">
<form action="#">
<div class="fields">
<div class="input-fields">
<label>NAME</label>
<input type="text" placeholder="NAME">
</div>
<div class="input-fields">
<label>LOAN-AMOUNT</label>
<input type="number" placeholder="LOAN-AMOUNT">
</div>
<div class="input-fields">
<label>PAYMENT-NUMBER</label>
<input type="number" placeholder="PAYMENT-NUMBER">
</div>
<div class="input-fields">
<label>PAYMENT-DATE</label>
<input type="date" placeholder="PAYMENT-DATE">
</div>
<div class="input-fields">
<label>PAYMENT-AMOUNT</label>
<input type="number" placeholder="PAYMENT-AMOUNT">
</div>
<div class="input-fields">
<label>INTEREST</label>
<input type="number" placeholder="INTEREST">
</div>
<div class="input-fields">
<label>PAYMENT-MODE</label>
<input type="text" placeholder="PAYMENT-MODE">
</div>
<div class="input-fields">
<button class="create-btn">PROCESS</button>
</div>
</div>
</div>
</div>
</form>
</div>
</body>
</html>