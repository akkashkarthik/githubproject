package com.Infotrixs.Payroll_System.Services;

import com.Infotrixs.Payroll_System.DTOs.Outgoing.EmployeeLoginDetails;

public interface EmployeeLoginService {
    EmployeeLoginDetails employeeLogin();
}
