package com.Infotrixs.Payroll_System.Enums;

public enum PaymentStatus {
    PAID,
    UNPAID
}
