package com.Infotrixs.Payroll_System.Enums;

public enum EmploymentLevel {
    TRAINEE,
    ASSOCIATE,
    SENIOR,
    MANAGER
}
