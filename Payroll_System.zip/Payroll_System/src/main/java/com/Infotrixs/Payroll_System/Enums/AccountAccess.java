package com.Infotrixs.Payroll_System.Enums;

public enum AccountAccess {
    GRANTED,
    RESTRICTED
}
