package com.Infotrixs.Payroll_System.Services;

import com.Infotrixs.Payroll_System.DTOs.Outgoing.AdminLoginDetails;

public interface AdminLoginService {

    AdminLoginDetails adminLogin();
}
