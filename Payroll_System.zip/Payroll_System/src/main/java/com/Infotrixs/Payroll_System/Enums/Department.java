package com.Infotrixs.Payroll_System.Enums;

public enum Department {
    SALES,
    MARKETING,
    ENGINEERING,
    FINANCE,
    HR
}
